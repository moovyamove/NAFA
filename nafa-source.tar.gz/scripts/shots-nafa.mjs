/** Captures NAFA : landing, convertisseur, login OTP, dashboard, envoi, admin. */
import puppeteer from "puppeteer";
import { mkdirSync } from "node:fs";

const BASE = process.argv[2];
const OUT = "public/shots";
mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
});
const p = await browser.newPage();
await p.setViewport({ width: 390, height: 844, isMobile: true, deviceScaleFactor: 2 });

console.log("1. Landing + convertisseur");
await p.goto(BASE, { waitUntil: "networkidle0", timeout: 60000 });
await sleep(2500);
await p.screenshot({ path: `${OUT}/n01-landing.png` });
await p.evaluate(() => window.scrollTo(0, 300));
await sleep(400);
await p.screenshot({ path: `${OUT}/n02-converter.png` });

console.log("2. Mode sombre");
await p.evaluate(() => {
  localStorage.setItem("nafa-theme", "dark");
  document.documentElement.classList.add("dark");
});
await p.goto(BASE, { waitUntil: "networkidle0" });
await sleep(2500);
await p.evaluate(() => window.scrollTo(0, 300));
await sleep(300);
await p.screenshot({ path: `${OUT}/n03-dark.png` });
await p.evaluate(() => {
  localStorage.setItem("nafa-theme", "light");
  document.documentElement.classList.remove("dark");
});

console.log("3. Login OTP");
await p.goto(`${BASE}/login`, { waitUntil: "networkidle0" });
await p.type("input", "+2348100000000");
await p.screenshot({ path: `${OUT}/n04-login.png` });
await p.click('button[type="submit"]');
await sleep(1500);
const devCode = await p.evaluate(() => {
  const el = [...document.querySelectorAll("p")].find((x) => /^\d{6}$/.test((x.textContent ?? "").trim()));
  return el?.textContent?.trim() ?? null;
});
console.log("   code démo:", devCode);
if (devCode) {
  await p.type("input", devCode);
  await p.click('button[type="submit"]');
  await sleep(3000);
  console.log("   URL après login:", p.url());
}

console.log("4. Dashboard");
await p.goto(`${BASE}/dashboard`, { waitUntil: "networkidle0" });
await sleep(1200);
await p.screenshot({ path: `${OUT}/n05-dashboard.png`, fullPage: true });

console.log("5. Envoi — étapes");
await p.goto(`${BASE}/send?dir=NGN_XOF&kind=parallel&amount=50000`, { waitUntil: "networkidle0" });
await sleep(1800);
await p.screenshot({ path: `${OUT}/n06-send.png`, fullPage: true });
// étape 2
await p.evaluate(() => [...document.querySelectorAll("button")].find((b) => (b.textContent ?? "").includes("Continuer"))?.click());
await sleep(600);
await p.type("input#bn", "Kofi Mensah");
await p.type("input#acct", "97123456");
await p.screenshot({ path: `${OUT}/n07-beneficiary.png` });
// étape 3 recap
await p.evaluate(() => [...document.querySelectorAll("button")].find((b) => (b.textContent ?? "").includes("Vérifier"))?.click());
await sleep(700);
await p.screenshot({ path: `${OUT}/n08-recap.png` });
// confirm
await p.evaluate(() => [...document.querySelectorAll("button")].find((b) => (b.textContent ?? "").includes("Confirmer l'envoi"))?.click());
await sleep(3500);
console.log("   URL succès:", p.url());
await p.screenshot({ path: `${OUT}/n09-confirmed.png` });

console.log("6. Suivi en direct");
const trackUrl = await p.evaluate(() => document.querySelector('a[href^="/tx/"]')?.href);
if (trackUrl) {
  await p.goto(trackUrl, { waitUntil: "networkidle0" });
  await sleep(2500);
  await p.screenshot({ path: `${OUT}/n10-tracking.png`, fullPage: true });
}

console.log("7. Admin");
const p2 = await browser.newPage();
await p2.setViewport({ width: 1280, height: 900 });
await p2.goto(`${BASE}/login`, { waitUntil: "networkidle0" });
await p2.type("input", "+2349000000001");
await p2.click('button[type="submit"]');
await sleep(1500);
const adminCode = await p2.evaluate(() => {
  const el = [...document.querySelectorAll("p")].find((x) => /^\d{6}$/.test((x.textContent ?? "").trim()));
  return el?.textContent?.trim() ?? null;
});
if (adminCode) {
  await p2.type("input", adminCode);
  await p2.click('button[type="submit"]');
  await sleep(2500);
}
await p2.goto(`${BASE}/admin`, { waitUntil: "networkidle0" });
await sleep(1200);
await p2.screenshot({ path: `${OUT}/n11-admin.png`, fullPage: true });
console.log("   admin URL:", p2.url());

await browser.close();
console.log("✔ captures terminées");
