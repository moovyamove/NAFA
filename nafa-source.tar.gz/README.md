# NAFA — Envoi Naira ⇄ CFA (NGN ⇄ XOF)

Application FinTech de démonstration d'échange de devises entre le **Naira
nigérian (NGN)** et le **Franc CFA UEMOA (XOF)** : Bénin, Togo, Côte d'Ivoire,
Sénégal, Burkina Faso, Mali, Niger, Guinée-Bissau.

> ⚠️ Démonstration : **aucun argent réel ne circule**. Les cours sont
> indicatifs, la recharge de portefeuille est simulée, et l'accès au
> portefeuille de code OTP est affiché à l'écran tant qu'aucun fournisseur
> SMS n'est branché.

## Fonctionnalités

### Convertisseur instantané (page d'accueil, sans compte)
- Bidirectionnel NGN ⇄ XOF, calcul temps réel débouncé.
- **Double marché** : taux officiel vs marché parallèle, avec marge affichée.
- Pays d'origine/destination avec **drapeaux SVG** des 9 pays.
- Méthodes de réception filtrées par zone :
  - **XOF** : Wave, MTN Mobile Money, Orange Money, Moov Money, virement UEMOA.
  - **NGN** : virement bancaire (NIP), Kuda, OPay, PalmPay.
- Détail transparent avant tout clic : taux appliqué, frais (% + fixe), montant converti, montant reçu, délai.

### Envoi en 4 étapes
1. Simulation (taux + frais) — 2. Bénéficiaire (validation du format du compte selon la méthode) — 3. Récapitulatif — 4. Confirmation avec **identifiant unique `NAFA-AAAA-XXXXXX`** et **suivi en direct** (polling 4 s, progression temps réel : En attente → En cours → Réussi).

### Compte (téléphone + OTP, sans mot de passe)
- `+234`/`+229`/… → code à 6 chiffres (renvoyé dans la réponse en mode démo sans `SMS_API_KEY`).
- Première visite : seul le nom est demandé.
- Sessions JWT httpOnly 30 jours (SameSite=None + Secure + CHIPS en production — compatible iframe ; Lax en dev).

### Tableau de bord
- Deux portefeuilles (NGN, XOF) en **unités mineures** (zéro erreur d'arrondi float), recharge instantanée de démo, notifications (transferts, alertes déclenchées), historique complet.

### Alertes de taux
- Seuil ≥ / ≤ sur chaque marché et chaque direction, déclenchées automatiquement à chaque mise à jour de cours (édition manuelle ou API), notification en cloche. Max 10 actives.

### Administration (`/admin`, rôle ADMIN)
- KPIs, édition des deux cours + marge, **actualisation via API publique** (`open.er-api.com`, repli propre sur taux manuel si injoignable), validation manuelle des transactions (décisions souveraines — la progression simulée ne les écrase jamais), liste des utilisateurs.

### Technique & sécurité
- Next.js App Router · PostgreSQL · Drizzle ORM · TypeScript strict.
- **Montants en unités mineures x100** ; quote recalculée AUTORITATIVEMENT côté serveur à la création (le calcul client n'est qu'un affichage).
- Débit du portefeuille **atomique** (transaction SQL conditionnée sur le solde).
- Garde CSRF d'origine sur toutes les mutations (`src/proxy.ts`), rate limiting par compte/IP, validation zod partout, OTP hashé SHA-256 à usage unique (10 min).
- **Base auto-guérissante** (`src/lib/bootstrap.ts`) : si l'environnement repart d'une base vide, schéma + référentiels sont recréés automatiquement à la prochaine requête — jamais destructif quand les tables existent.
- Mode sombre/clair persistant, PWA (manifest + icône), mobile-first.

## Démarrage

```bash
cp .env.example .env            # DATABASE_URL + AUTH_SECRET
npm install
npx drizzle-kit push            # crée les tables
DATABASE_URL=... npx tsx src/db/seed.ts
npm run dev
```

### Comptes de démonstration (OTP affiché à l'écran)
| Rôle | Téléphone |
|---|---|
| Utilisateur démo (portefeuilles remplis + historique) | `+2348100000000` |
| Administrateur | `+2349000000001` |

## Variables d'environnement

| Variable | Rôle |
|---|---|
| `DATABASE_URL` | PostgreSQL (obligatoire) |
| `AUTH_SECRET` | Signature des sessions JWT (`openssl rand -hex 32`) |
| `SMS_API_KEY` | Si définie : le code OTP n'est plus renvoyé en réponse (branchement Twilio / Africa's Talking à faire dans `/api/auth/otp/request`) |

## Feuille de route

- [ ] **KYC** (CNI / passeport, anti-blanchiment) — structure d'utilisateurs déjà rôle-driven.
- [ ] Persistance des abonnements aux alertes par push (Web Push / FCM).
- [ ] PSP réel (Wave API, MoMo API) derrière `POST /api/transactions`.
- [ ] Historique graphique des cours.
- [ ] Export comptable CSV pour l'admin.
