CREATE TYPE "public"."direction" AS ENUM('NGN_XOF', 'XOF_NGN');--> statement-breakpoint
CREATE TYPE "public"."method_type" AS ENUM('mobile_money', 'bank', 'fintech');--> statement-breakpoint
CREATE TYPE "public"."rate_kind" AS ENUM('official', 'parallel');--> statement-breakpoint
CREATE TYPE "public"."role" AS ENUM('USER', 'ADMIN');--> statement-breakpoint
CREATE TYPE "public"."tx_status" AS ENUM('pending', 'processing', 'success', 'failed');--> statement-breakpoint
CREATE TYPE "public"."zone" AS ENUM('NG', 'XOF');--> statement-breakpoint
CREATE TABLE "activity_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid,
	"action" varchar(60) NOT NULL,
	"meta" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"title" varchar(120) NOT NULL,
	"body" varchar(240) NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "otp_codes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"phone" varchar(20) NOT NULL,
	"code_hash" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"used_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payout_methods" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"zone" "zone" NOT NULL,
	"code" varchar(30) NOT NULL,
	"label" varchar(60) NOT NULL,
	"type" "method_type" NOT NULL,
	"fee_percent" numeric(5, 3) DEFAULT '1.500' NOT NULL,
	"fee_fixed_ngn" integer DEFAULT 0 NOT NULL,
	"fee_fixed_xof" integer DEFAULT 0 NOT NULL,
	"eta_label" varchar(40) DEFAULT 'Instantané' NOT NULL,
	"color" varchar(16) DEFAULT '#0f172a' NOT NULL,
	"account_hint" varchar(90) DEFAULT '' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "payout_methods_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "rate_alerts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"direction" "direction" NOT NULL,
	"rate_kind" "rate_kind" NOT NULL,
	"threshold" numeric(14, 6) NOT NULL,
	"above" boolean DEFAULT true NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"triggered_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rates" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"kind" "rate_kind" NOT NULL,
	"ngn_to_xof" numeric(14, 6) NOT NULL,
	"xof_to_ngn" numeric(14, 6) NOT NULL,
	"margin_percent" numeric(5, 3) DEFAULT '1.000' NOT NULL,
	"source" varchar(40) DEFAULT 'manual' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "rates_kind_unique" UNIQUE("kind")
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tracking_id" varchar(24) NOT NULL,
	"sender_id" uuid NOT NULL,
	"method_id" uuid NOT NULL,
	"direction" "direction" NOT NULL,
	"rate_kind" "rate_kind" NOT NULL,
	"rate_applied" numeric(14, 6) NOT NULL,
	"country_from" varchar(40) NOT NULL,
	"country_to" varchar(40) NOT NULL,
	"beneficiary_name" varchar(90) NOT NULL,
	"beneficiary_account" varchar(40) NOT NULL,
	"send_amount" bigint NOT NULL,
	"fee_amount" bigint NOT NULL,
	"receive_amount" bigint NOT NULL,
	"status" "tx_status" DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "transactions_tracking_id_unique" UNIQUE("tracking_id")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"phone" varchar(20) NOT NULL,
	"name" varchar(80) NOT NULL,
	"role" "role" DEFAULT 'USER' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_phone_unique" UNIQUE("phone")
);
--> statement-breakpoint
CREATE TABLE "wallets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"ngn_balance" bigint DEFAULT 0 NOT NULL,
	"xof_balance" bigint DEFAULT 0 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "wallets_user_id_unique" UNIQUE("user_id")
);
--> statement-breakpoint
ALTER TABLE "activity_logs" ADD CONSTRAINT "activity_logs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "rate_alerts" ADD CONSTRAINT "rate_alerts_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_sender_id_users_id_fk" FOREIGN KEY ("sender_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_method_id_payout_methods_id_fk" FOREIGN KEY ("method_id") REFERENCES "public"."payout_methods"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wallets" ADD CONSTRAINT "wallets_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "notif_user_idx" ON "notifications" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "alerts_user_idx" ON "rate_alerts" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "tx_sender_idx" ON "transactions" USING btree ("sender_id");--> statement-breakpoint
CREATE INDEX "tx_created_idx" ON "transactions" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "tx_tracking_idx" ON "transactions" USING btree ("tracking_id");--> statement-breakpoint
CREATE INDEX "users_phone_idx" ON "users" USING btree ("phone");