/**
 * Seed NAFA — taux, méthodes de réception, comptes démo.
 * Idempotent : vide les référentiels puis réinsère (n'efface les données
 * utilisateurs que sur ré-exécution explicite en CLI).
 */
import { config } from "dotenv";
config();

import { db } from "@/db";
import {
  activityLogs,
  notifications,
  otpCodes,
  payoutMethods,
  rateAlerts,
  rates,
  transactions,
  users,
  wallets,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { makeTrackingId } from "@/lib/money";

export const ADMIN_PHONE = "+2349000000001";
export const DEMO_PHONE = "+2348100000000";

export async function runSeed({ withUsers = true }: { withUsers?: boolean } = {}) {
  console.log("→ Taux & méthodes…");

  await db.delete(notifications);
  await db.delete(rateAlerts);
  await db.delete(transactions);
  await db.delete(payoutMethods);
  await db.delete(rates);
  await db.delete(otpCodes);
  if (withUsers) {
    await db.delete(activityLogs);
    await db.delete(wallets);
    await db.delete(users);
  }

  await db.insert(rates).values([
    {
      kind: "official",
      ngnToXof: "0.382500",
      xofToNgn: "2.614800",
      marginPercent: "1.000",
      source: "manual",
    },
    {
      kind: "parallel",
      ngnToXof: "0.445200",
      xofToNgn: "2.246100",
      marginPercent: "1.500",
      source: "manual",
    },
  ]);

  const methods = await db
    .insert(payoutMethods)
    .values([
      // Zone XOF — réception en francs CFA
      { zone: "XOF", code: "wave", label: "Wave", type: "mobile_money", feePercent: "1.200", feeFixedNgn: 0, feeFixedXof: 5000, etaLabel: "Instantané", color: "#1dc4e9", accountHint: "Numéro Wave (8 chiffres)", sortOrder: 1 },
      { zone: "XOF", code: "mtn-momo", label: "MTN Mobile Money", type: "mobile_money", feePercent: "1.500", feeFixedNgn: 0, feeFixedXof: 10000, etaLabel: "Instantané", color: "#ffcc00", accountHint: "Numéro MTN MoMo", sortOrder: 2 },
      { zone: "XOF", code: "orange-money", label: "Orange Money", type: "mobile_money", feePercent: "1.500", feeFixedNgn: 0, feeFixedXof: 10000, etaLabel: "Instantané", color: "#ff7900", accountHint: "Numéro Orange Money", sortOrder: 3 },
      { zone: "XOF", code: "moov-money", label: "Moov Money", type: "mobile_money", feePercent: "1.500", feeFixedNgn: 0, feeFixedXof: 10000, etaLabel: "Instantané", color: "#0066b3", accountHint: "Numéro Moov Money", sortOrder: 4 },
      { zone: "XOF", code: "bank-xof", label: "Virement bancaire UEMOA", type: "bank", feePercent: "2.000", feeFixedNgn: 0, feeFixedXof: 50000, etaLabel: "Jour ouvré", color: "#475569", accountHint: "RIB ou IBAN UEMOA (24 caractères)", sortOrder: 5 },
      // Zone Nigeria — réception en naira
      { zone: "NG", code: "bank-ng", label: "Transfert bancaire NGN", type: "bank", feePercent: "1.800", feeFixedNgn: 10000, feeFixedXof: 0, etaLabel: "Instantané (NIP)", color: "#005baa", accountHint: "Numéro de compte (10 chiffres NUBAN)", sortOrder: 10 },
      { zone: "NG", code: "kuda", label: "Kuda Bank", type: "fintech", feePercent: "1.200", feeFixedNgn: 5000, feeFixedXof: 0, etaLabel: "Instantané", color: "#40196d", accountHint: "Compte Kuda (10 chiffres)", sortOrder: 11 },
      { zone: "NG", code: "opay", label: "OPay", type: "fintech", feePercent: "1.000", feeFixedNgn: 0, feeFixedXof: 0, etaLabel: "Instantané", color: "#00b48b", accountHint: "Compte OPay (téléphone)", sortOrder: 12 },
      { zone: "NG", code: "palmpay", label: "PalmPay", type: "fintech", feePercent: "1.000", feeFixedNgn: 0, feeFixedXof: 0, etaLabel: "Instantané", color: "#6c2bd9", accountHint: "Compte PalmPay (téléphone)", sortOrder: 13 },
    ])
    .returning();
  const byCode = new Map(methods.map((m) => [m.code, m]));
  console.log(`  ✓ 2 taux · ${methods.length} méthodes`);

  if (withUsers) {
    console.log("→ Comptes démo…");
    const [admin, amara] = await db
      .insert(users)
      .values([
        { phone: ADMIN_PHONE, name: "Équipe NAFA", role: "ADMIN" },
        { phone: DEMO_PHONE, name: "Amara Diallo", role: "USER" },
      ])
      .returning();

    await db.insert(wallets).values([
      { userId: admin.id, ngnBalance: 0, xofBalance: 0 },
      { userId: amara.id, ngnBalance: 25_000_000, xofBalance: 15_000_000 }, // ₦250 000 · 150 000 F
    ]);

    // Historique de démonstration
    const wave = byCode.get("wave")!;
    const opay = byCode.get("opay")!;
    const demoTxs = [
      {
        trackingId: makeTrackingId(), senderId: amara.id, methodId: wave.id,
        direction: "NGN_XOF" as const, rateKind: "parallel" as const, rateApplied: "0.4385",
        countryFrom: "Nigeria", countryTo: "Bénin",
        beneficiaryName: "Kofi Mensah", beneficiaryAccount: "97123456",
        sendAmount: 5_000_000, feeAmount: 60_000, receiveAmount: 2_166_183, status: "success" as const,
        daysAgo: 6,
      },
      {
        trackingId: makeTrackingId(), senderId: amara.id, methodId: wave.id,
        direction: "NGN_XOF" as const, rateKind: "official" as const, rateApplied: "0.3787",
        countryFrom: "Nigeria", countryTo: "Togo",
        beneficiaryName: "Awa Sarr", beneficiaryAccount: "90998877",
        sendAmount: 2_000_000, feeAmount: 24_000, receiveAmount: 748_703, status: "success" as const,
        daysAgo: 3,
      },
      {
        trackingId: makeTrackingId(), senderId: amara.id, methodId: opay.id,
        direction: "XOF_NGN" as const, rateKind: "parallel" as const, rateApplied: "2.2125",
        countryFrom: "Côte d'Ivoire", countryTo: "Nigeria",
        beneficiaryName: "Chinedu Okafor", beneficiaryAccount: "08123456789",
        sendAmount: 3_000_000, feeAmount: 30_000, receiveAmount: 134_382, status: "success" as const,
        daysAgo: 1,
      },
      {
        trackingId: makeTrackingId(), senderId: amara.id, methodId: wave.id,
        direction: "NGN_XOF" as const, rateKind: "parallel" as const, rateApplied: "0.4385",
        countryFrom: "Nigeria", countryTo: "Bénin",
        beneficiaryName: "Kofi Mensah", beneficiaryAccount: "97123456",
        sendAmount: 1_500_000, feeAmount: 18_000, receiveAmount: 649_855, status: "processing" as const,
        daysAgo: 0,
      },
    ];
    for (const tx of demoTxs) {
      const { daysAgo, ...values } = tx;
      const at = new Date(Date.now() - daysAgo * 86400000 - 3600_000);
      await db.insert(transactions).values({
        ...values,
        createdAt: at,
        updatedAt: values.status === "success" ? at : new Date(),
      });
    }
    console.log(`  ✓ admin ${ADMIN_PHONE} · démo ${DEMO_PHONE} · ${demoTxs.length} transactions`);
  }
}

// CLI : npx tsx src/db/seed.ts
const isCli = process.argv[1]?.endsWith("seed.ts");
if (isCli) {
  runSeed()
    .then(() => process.exit(0))
    .catch((err: unknown) => {
      console.error("Seed failed:", err);
      process.exit(1);
    });
}
