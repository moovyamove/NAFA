import {
  pgTable,
  pgEnum,
  uuid,
  text,
  varchar,
  integer,
  bigint,
  boolean,
  timestamp,
  uniqueIndex,
  index,
  numeric,
} from "drizzle-orm/pg-core";

/* ---------------------------------- enums --------------------------------- */

export const roleEnum = pgEnum("role", ["USER", "ADMIN"]);
export const rateKindEnum = pgEnum("rate_kind", ["official", "parallel"]);
export const directionEnum = pgEnum("direction", ["NGN_XOF", "XOF_NGN"]);
export const zoneEnum = pgEnum("zone", ["NG", "XOF"]);
export const methodTypeEnum = pgEnum("method_type", ["mobile_money", "bank", "fintech"]);
export const txStatusEnum = pgEnum("tx_status", ["pending", "processing", "success", "failed"]);

/* ---------------------------------- users --------------------------------- */

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    phone: varchar("phone", { length: 20 }).notNull().unique(),
    name: varchar("name", { length: 80 }).notNull(),
    role: roleEnum("role").notNull().default("USER"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("users_phone_idx").on(t.phone)],
);

export const otpCodes = pgTable("otp_codes", {
  id: uuid("id").defaultRandom().primaryKey(),
  phone: varchar("phone", { length: 20 }).notNull(),
  codeHash: text("code_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* --------------------------------- wallets --------------------------------- */

/** Montants en unités mineures (x100). XOF est sans décimale, mais la même
 *  convention x100 évite toute classe d'erreur d'arrondi. */
export const wallets = pgTable("wallets", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  ngnBalance: bigint("ngn_balance", { mode: "number" }).notNull().default(0),
  xofBalance: bigint("xof_balance", { mode: "number" }).notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ---------------------------------- rates ---------------------------------- */

export const rates = pgTable("rates", {
  id: uuid("id").defaultRandom().primaryKey(),
  kind: rateKindEnum("kind").notNull().unique(), // une ligne par type de taux
  ngnToXof: numeric("ngn_to_xof", { precision: 14, scale: 6 }).notNull(),
  xofToNgn: numeric("xof_to_ngn", { precision: 14, scale: 6 }).notNull(),
  marginPercent: numeric("margin_percent", { precision: 5, scale: 3 }).notNull().default("1.000"),
  source: varchar("source", { length: 40 }).notNull().default("manual"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------ payout methods ----------------------------- */

export const payoutMethods = pgTable("payout_methods", {
  id: uuid("id").defaultRandom().primaryKey(),
  zone: zoneEnum("zone").notNull(), // NG = on reçoit en NGN · XOF = on reçoit en XOF
  code: varchar("code", { length: 30 }).notNull().unique(),
  label: varchar("label", { length: 60 }).notNull(),
  type: methodTypeEnum("type").notNull(),
  feePercent: numeric("fee_percent", { precision: 5, scale: 3 }).notNull().default("1.500"),
  feeFixedNgn: integer("fee_fixed_ngn").notNull().default(0), // kobo (x100)
  feeFixedXof: integer("fee_fixed_xof").notNull().default(0), // centimes (x100)
  etaLabel: varchar("eta_label", { length: 40 }).notNull().default("Instantané"),
  color: varchar("color", { length: 16 }).notNull().default("#0f172a"),
  accountHint: varchar("account_hint", { length: 90 }).notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

/* ------------------------------- transactions ------------------------------ */

export const transactions = pgTable(
  "transactions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    trackingId: varchar("tracking_id", { length: 24 }).notNull().unique(),
    senderId: uuid("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    methodId: uuid("method_id").notNull().references(() => payoutMethods.id),
    direction: directionEnum("direction").notNull(),
    rateKind: rateKindEnum("rate_kind").notNull(),
    rateApplied: numeric("rate_applied", { precision: 14, scale: 6 }).notNull(),
    countryFrom: varchar("country_from", { length: 40 }).notNull(),
    countryTo: varchar("country_to", { length: 40 }).notNull(),
    beneficiaryName: varchar("beneficiary_name", { length: 90 }).notNull(),
    beneficiaryAccount: varchar("beneficiary_account", { length: 40 }).notNull(),
    sendAmount: bigint("send_amount", { mode: "number" }).notNull(), // unités mineures, devise source
    feeAmount: bigint("fee_amount", { mode: "number" }).notNull(),
    receiveAmount: bigint("receive_amount", { mode: "number" }).notNull(), // unités mineures, devise cible
    status: txStatusEnum("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("tx_sender_idx").on(t.senderId),
    index("tx_created_idx").on(t.createdAt),
    index("tx_tracking_idx").on(t.trackingId),
  ],
);

/* --------------------------------- alerts ---------------------------------- */

export const rateAlerts = pgTable(
  "rate_alerts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    direction: directionEnum("direction").notNull(),
    rateKind: rateKindEnum("rate_kind").notNull(),
    threshold: numeric("threshold", { precision: 14, scale: 6 }).notNull(),
    above: boolean("above").notNull().default(true), // alerte quand taux >= ou <= seuil
    isActive: boolean("is_active").notNull().default(true),
    triggeredAt: timestamp("triggered_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("alerts_user_idx").on(t.userId)],
);

/* ------------------------------- notifications ----------------------------- */

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 120 }).notNull(),
    body: varchar("body", { length: 240 }).notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("notif_user_idx").on(t.userId)],
);

/* --------------------------------- audit log ------------------------------- */

export const activityLogs = pgTable("activity_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  action: varchar("action", { length: 60 }).notNull(),
  meta: text("meta"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------- inferred types ---------------------------- */

export type User = typeof users.$inferSelect;
export type Wallet = typeof wallets.$inferSelect;
export type Rate = typeof rates.$inferSelect;
export type PayoutMethod = typeof payoutMethods.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type RateAlert = typeof rateAlerts.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
