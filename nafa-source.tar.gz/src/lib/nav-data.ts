import { db } from "@/db";
import { notifications } from "@/db/schema";
import { and, eq, isNull, sql } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";

export async function getNavData() {
  const user = await getSessionUser();
  if (!user) return { user: null, unread: 0 };
  const [{ n = 0 } = {}] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(notifications)
    .where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));
  return { user: { name: user.name, role: user.role }, unread: n };
}
