import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const secret = new TextEncoder().encode(
  process.env.AUTH_SECRET ?? "nafa-dev-secret-change-me-in-production",
);

export const SESSION_COOKIE = "nafa_session";

export type SessionPayload = { sub: string; role: "USER" | "ADMIN" };

async function signToken(payload: object, expiresIn: string): Promise<string> {
  return new SignJWT(payload as Record<string, unknown>)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(expiresIn)
    .sign(secret);
}

/**
 * Cookies : l'aperçu est servi en iframe → SameSite=None + Secure + CHIPS
 * (Partitioned) en production ; Lax en dev local http.
 */
function sessionCookieOptions() {
  const secure = process.env.NODE_ENV === "production";
  return {
    httpOnly: true,
    sameSite: (secure ? "none" : "lax") as "none" | "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: 60 * 60 * 24 * 30, // 30 jours
  };
}

export async function createSession(userId: string, role: "USER" | "ADMIN") {
  const store = await cookies();
  const token = await signToken({ sub: userId, role }, "30d");
  store.set(SESSION_COOKIE, token, sessionCookieOptions());
}

export async function destroySession() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    const p = payload as SessionPayload;
    if (!p.sub || (p.role !== "USER" && p.role !== "ADMIN")) return null;
    return p;
  } catch {
    return null;
  }
}

export async function getSessionUser() {
  const session = await getSession();
  if (!session) return null;
  const [user] = await db
    .select({ id: users.id, phone: users.phone, name: users.name, role: users.role })
    .from(users)
    .where(eq(users.id, session.sub))
    .limit(1);
  return user ?? null;
}

/* ------------------------------- rate limiting ----------------------------- */

const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true as const };
  }
  if (bucket.count >= limit) {
    return { ok: false as const, retryAfter: Math.ceil((bucket.resetAt - now) / 1000) };
  }
  bucket.count += 1;
  return { ok: true as const };
}
