import type { PayoutMethod, Rate } from "@/db/schema";

/* ------------------------- unités mineures (x100) -------------------------- */

export type Currency = "NGN" | "XOF";
export type Direction = "NGN_XOF" | "XOF_NGN";
export type RateKind = "official" | "parallel";

export const CURRENCY_META: Record<
  Currency,
  { symbol: string; digits: number; label: string }
> = {
  NGN: { symbol: "₦", digits: 2, label: "Naira nigérian" },
  XOF: { symbol: "F CFA", digits: 0, label: "Franc CFA UEMOA" },
};

/** "12500.50" → 1250050 (unités mineures, arrondi sûr, jamais de float direct) */
export function majorToMinor(major: number, currency: Currency): number {
  const meta = CURRENCY_META[currency];
  const factor = 10 ** 2; // stockage interne toujours x100
  if (!Number.isFinite(major) || major < 0) return 0;
  const rounded = Number(major.toFixed(meta.digits));
  return Math.round(rounded * factor);
}

export function minorToMajor(minor: number): number {
  return minor / 100;
}

export function formatMinor(minor: number, currency: Currency): string {
  const meta = CURRENCY_META[currency];
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency,
    minimumFractionDigits: meta.digits,
    maximumFractionDigits: meta.digits,
    currencyDisplay: currency === "NGN" ? "symbol" : "narrowSymbol",
  }).format(minor / 100);
}

export function formatRate(rate: number, dir: Direction): string {
  const digits = dir === "NGN_XOF" ? 4 : 3;
  return new Intl.NumberFormat("fr-FR", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(rate);
}

/* ------------------------------- quote engine ------------------------------ */

export type Quote = {
  direction: Direction;
  rateKind: RateKind;
  rate: number; // taux appliqué (marge incluse)
  sendAmount: number; // minor, devise source
  feePercent: number;
  feeFixed: number; // minor, source
  feeAmount: number; // minor, source
  netAmount: number; // minor, source
  receiveAmount: number; // minor, devise cible
  sourceCurrency: Currency;
  targetCurrency: Currency;
};

export function directionMeta(dir: Direction) {
  return dir === "NGN_XOF"
    ? { source: "NGN" as Currency, target: "XOF" as Currency }
    : { source: "XOF" as Currency, target: "NGN" as Currency };
}

export function appliedRate(rate: Rate, dir: Direction): number {
  const base = dir === "NGN_XOF" ? Number(rate.ngnToXof) : Number(rate.xofToNgn);
  const margin = 1 - Number(rate.marginPercent) / 100;
  const value = base * margin;
  return Math.round(value * 1_000_000) / 1_000_000;
}

export function computeQuote(params: {
  direction: Direction;
  rateKind: RateKind;
  sendMinor: number;
  rate: Rate;
  method: PayoutMethod;
}): Quote {
  const { direction, rateKind, sendMinor, rate, method } = params;
  const { source, target } = directionMeta(direction);
  const applied = appliedRate(rate, direction);

  const feePercent = Number(method.feePercent);
  const feeFixed = source === "NGN" ? method.feeFixedNgn : method.feeFixedXof;
  const rawFee = Math.round((sendMinor * feePercent) / 100) + feeFixed;
  const feeAmount = Math.min(rawFee, sendMinor); // jamais de frais > montant
  const netAmount = Math.max(0, sendMinor - feeAmount);

  const receiveAmount =
    direction === "NGN_XOF"
      ? Math.round((netAmount / 100) * applied * 100)
      : Math.round((netAmount / 100 / applied) * 100);

  return {
    direction,
    rateKind,
    rate: applied,
    sendAmount: sendMinor,
    feePercent,
    feeFixed,
    feeAmount,
    netAmount,
    receiveAmount,
    sourceCurrency: source,
    targetCurrency: target,
  };
}

/* ------------------------------- tracking id ------------------------------- */

export function makeTrackingId(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let suffix = "";
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  for (const b of bytes) suffix += alphabet[b % alphabet.length];
  return `NAFA-${new Date().getFullYear()}-${suffix}`;
}
