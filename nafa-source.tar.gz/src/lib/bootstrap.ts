import { db } from "@/db";
import { sql } from "drizzle-orm";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

/**
 * Auto-guérison : certains environnements d'aperçu repartent d'une base
 * PostgreSQL toute vide. À CHAQUE accès, on vérifie l'existence de la table
 * `games` (1 requête triviale) ; si elle est absente, les migrations générées
 * sont ré-appliquées et le catalogue ré-injecté — la requête en cours est
 * alors servie normalement (pas d'écran d'erreur).
 *
 * Garanties : jamais destructive (ne s'exécute que quand la table manque),
 * un seul bootstrap concurrent (verrou par promesse), tolérant aux
 * ré-exécutions (erreurs « already exists » ignorées).
 */

let bootPromise: Promise<void> | null = null;

export async function ensureDatabase(): Promise<void> {
  if (await tableExists("rates")) return;
  bootPromise ??= applyMigrationsAndSeed().finally(() => {
    bootPromise = null;
  });
  await bootPromise;
}

async function tableExists(name: string): Promise<boolean> {
  try {
    const result = (await db.execute(
      sql`select to_regclass(${"public." + name}) as t`,
    )) as unknown as { rows?: { t: string | null }[] };
    return !!result.rows?.[0]?.t;
  } catch {
    return false;
  }
}

async function applyMigrationsAndSeed(): Promise<void> {
  console.warn("[kidora] Tables absentes — application des migrations SQL…");
  const dir = join(process.cwd(), "drizzle");
  const files = readdirSync(dir)
    .filter((f) => f.endsWith(".sql"))
    .sort();
  for (const file of files) {
    const content = readFileSync(join(dir, file), "utf8");
    let index = 0;
    for (const chunk of content.split("--> statement-breakpoint")) {
      const statement = chunk.trim();
      index += 1;
      if (statement.length === 0) continue;
      try {
        await db.execute(sql.raw(statement));
      } catch (err) {
        // Ré-exécutions/concurrence : ignorer les objets déjà créés.
        console.warn(
          `[kidora] migration ${file}#${index} ignorée:`,
          err instanceof Error ? err.message.slice(0, 90) : err,
        );
      }
    }
  }

  if (!(await tableExists("rates"))) {
    throw new Error("Bootstrap impossible : la table rates n'a pas été créée.");
  }
  console.warn("[kidora] Injection du catalogue…");
  const { runSeed } = await import("@/db/seed");
  await runSeed();
  console.warn("[kidora] Bootstrap terminé ✔");
}
