import { NextRequest, NextResponse } from "next/server";
import { ensureDatabase } from "@/lib/bootstrap";

/**
 * Garde CSRF applicative (Next.js 16 — convention "proxy").
 *
 * Les cookies de session sont SameSite=None/Secure (l'app est embarquée en
 * iframe dans l'aperçu hébergé) : SameSite ne protège donc plus à lui seul.
 * On compense en refusant toute mutation d'API dont l'en-tête Origin pointe
 * vers un autre hôte que celui de la requête.
 */
const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);

export async function proxy(req: NextRequest) {
  // S'assure que la base est prête avant toute requête API (auto-guérison).
  await ensureDatabase();
  if (!MUTATING_METHODS.has(req.method)) {
    return NextResponse.next();
  }
  const origin = req.headers.get("origin");
  // Les clients sans Origin (curl, apps natives futures) ne sont pas soumis à
  // l'en-tête : elles ne transportent pas de cookies de navigateur tiers.
  if (origin) {
    let originHost: string | null = null;
    try {
      originHost = new URL(origin).host;
    } catch {
      originHost = null;
    }
    const host = req.headers.get("host");
    if (!originHost || !host || originHost !== host) {
      return NextResponse.json(
        { error: "Requête bloquée (origine invalide)." },
        { status: 403 },
      );
    }
  }
  return NextResponse.next();
}

export const config = {
  // Pages + API : la base doit être prête AVANT tout rendu (Next.js exécute
  // layouts et pages en parallèle ; seul le proxy garantit l'ordre).
  // Exclus : assets statiques et fichiers publics.
  matcher: [
    "/((?!_next/static|_next/image|images/|shots/|icon.png|manifest|favicon).*)",
  ],
};
