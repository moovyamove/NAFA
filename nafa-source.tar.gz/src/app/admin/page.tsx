import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { payoutMethods, rateAlerts, rates, transactions, users } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { appliedRate, formatMinor, formatRate } from "@/lib/money";
import { RateEditor, RefreshRatesButton, TxStatusButtons } from "@/components/admin-actions";
import { DirectionChip, Logo, StatusPill } from "@/components/flags";
import { LogoutButton } from "@/components/admin-logout";
import { Activity, Bell, ShieldCheck, TrendingUp, Users } from "lucide-react";

export const metadata: Metadata = { title: "Administration" };
export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const session = await getSession();
  if (!session) redirect("/login?next=/admin");
  if (session.role !== "ADMIN") redirect("/dashboard");

  const [{ txCount = 0 } = {}] = await db.select({ txCount: sql<number>`count(*)::int` }).from(transactions);
  const [{ usersCount = 0 } = {}] = await db.select({ usersCount: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "USER"));
  const [{ alertsCount = 0 } = {}] = await db.select({ alertsCount: sql<number>`count(*)::int` }).from(rateAlerts).where(eq(rateAlerts.isActive, true));
  const [{ volume = 0 } = {}] = await db
    .select({ volume: sql<number>`coalesce(sum(${transactions.sendAmount}),0)::bigint` })
    .from(transactions)
    .where(eq(transactions.status, "success"));

  const rateRows = await db.select().from(rates);
  const txs = await db
    .select({
      trackingId: transactions.trackingId,
      direction: transactions.direction,
      status: transactions.status,
      sendAmount: transactions.sendAmount,
      receiveAmount: transactions.receiveAmount,
      beneficiary: transactions.beneficiaryName,
      phone: users.phone,
      methodLabel: payoutMethods.label,
      createdAt: transactions.createdAt,
    })
    .from(transactions)
    .innerJoin(users, eq(transactions.senderId, users.id))
    .innerJoin(payoutMethods, eq(transactions.methodId, payoutMethods.id))
    .orderBy(desc(transactions.createdAt))
    .limit(15);
  const userRows = await db
    .select({ phone: users.phone, name: users.name, role: users.role, createdAt: users.createdAt })
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(8);

  const kpis = [
    { icon: Activity, label: "Transactions", value: txCount },
    { icon: Users, label: "Utilisateurs", value: usersCount },
    { icon: Bell, label: "Alertes actives", value: alertsCount },
    { icon: TrendingUp, label: "Volume réussi", value: `${Math.round(volume / 1000000)} k` },
  ];

  return (
    <div className="min-h-dvh bg-slate-950 text-slate-100">
      <header className="border-b border-white/10">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
          <span className="[&_*]:!text-white"><Logo /></span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-400/10 px-3 py-1 text-xs font-bold text-amber-300">
            <ShieldCheck className="h-3.5 w-3.5" /> Administration
          </span>
          <LogoutButton />
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-8 px-4 py-8">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {kpis.map((k) => (
            <div key={k.label} className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <k.icon className="h-5 w-5 text-nafa-400" />
              <p className="mt-2 font-display text-2xl font-bold">{k.value}</p>
              <p className="text-xs font-bold text-slate-400">{k.label}</p>
            </div>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {rateRows.map((r) => (
            <section key={r.kind} className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <h2 className="font-display text-lg font-bold capitalize">
                {r.kind === "official" ? "Taux officiel" : "Marché parallèle"}
              </h2>
              <p className="mt-1 text-xs font-semibold text-slate-400">
                Appliqué : 1 ₦ = {formatRate(appliedRate(r, "NGN_XOF"), "NGN_XOF")} F · marge {Number(r.marginPercent)} % · source {r.source}
              </p>
              <div className="mt-4">
                <RateEditor
                  kind={r.kind}
                  initial={{
                    ngnToXof: Number(r.ngnToXof),
                    xofToNgn: Number(r.xofToNgn),
                    marginPercent: Number(r.marginPercent),
                  }}
                />
              </div>
            </section>
          ))}
        </div>
        <RefreshRatesButton />

        <section className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h2 className="font-display text-lg font-bold">Dernières transactions</h2>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead>
                <tr className="text-xs uppercase text-slate-500">
                  <th className="pb-2">ID</th><th className="pb-2">Utilisateur</th><th className="pb-2">Sens</th><th className="pb-2">Montant</th><th className="pb-2">Statut</th><th className="pb-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {txs.map((t) => (
                  <tr key={t.trackingId} className="border-t border-white/5">
                    <td className="py-3 font-mono text-xs">{t.trackingId}</td>
                    <td className="py-3 text-xs text-slate-400">{t.phone}</td>
                    <td className="py-3"><DirectionChip direction={t.direction} /></td>
                    <td className="py-3 text-xs font-bold">
                      {formatMinor(t.sendAmount, t.direction === "NGN_XOF" ? "NGN" : "XOF")} → {formatMinor(t.receiveAmount, t.direction === "NGN_XOF" ? "XOF" : "NGN")}
                    </td>
                    <td className="py-3"><StatusPill status={t.status} /></td>
                    <td className="py-3"><TxStatusButtons trackingId={t.trackingId} current={t.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h2 className="font-display text-lg font-bold">Utilisateurs récents</h2>
          <ul className="mt-4 space-y-2">
            {userRows.map((u) => (
              <li key={u.phone} className="flex items-center justify-between rounded-xl bg-white/5 px-4 py-2.5 text-sm">
                <span className="font-bold">{u.name}</span>
                <span className="text-xs text-slate-400">{u.phone} · {u.role}</span>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
