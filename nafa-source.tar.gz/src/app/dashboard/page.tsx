import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { notifications, payoutMethods, transactions, wallets } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { formatMinor } from "@/lib/money";
import { getNavData } from "@/lib/nav-data";
import { Nav } from "@/components/nav";
import { DirectionChip, Flag, StatusPill } from "@/components/flags";
import { TopupButton } from "@/components/topup-button";
import {
  ArrowRight, ArrowUpRight, Bell, Plus, Send, Wallet2,
} from "lucide-react";

export const metadata: Metadata = { title: "Tableau de bord" };
export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login?next=/dashboard");
  const { user, unread } = await getNavData();

  const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, session.sub)).limit(1);
  const recent = await db
    .select({
      trackingId: transactions.trackingId,
      direction: transactions.direction,
      status: transactions.status,
      sendAmount: transactions.sendAmount,
      receiveAmount: transactions.receiveAmount,
      countryTo: transactions.countryTo,
      methodLabel: payoutMethods.label,
      methodColor: payoutMethods.color,
      createdAt: transactions.createdAt,
    })
    .from(transactions)
    .innerJoin(payoutMethods, eq(transactions.methodId, payoutMethods.id))
    .where(eq(transactions.senderId, session.sub))
    .orderBy(desc(transactions.createdAt))
    .limit(8);
  const notifs = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, session.sub))
    .orderBy(desc(notifications.createdAt))
    .limit(6);

  return (
    <div className="pb-24 md:pb-0">
      <Nav user={user} unread={unread} />
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-6">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl font-bold sm:text-3xl">
            Salut, {user?.name.split(" ")[0]} 👋
          </h1>
          <Link href="/"
            className="btn-3d inline-flex items-center gap-2 rounded-2xl bg-night-900 px-5 py-3 font-display font-bold text-white shadow-card dark:bg-nafa-500 dark:text-night-950">
            <Send className="h-4 w-4" /> Nouveau transfert
          </Link>
        </div>

        {/* Portefeuilles */}
        <div className="grid gap-4 sm:grid-cols-2">
          <section className="relative overflow-hidden rounded-[1.75rem] bg-night-900 p-6 text-white shadow-deep">
            <div className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full bg-nafa-500/20 blur-2xl" />
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-white/60">
                <Flag code="NG" className="h-4 w-6" /> Portefeuille Naira
              </span>
              <Wallet2 className="h-5 w-5 text-white/40" />
            </div>
            <p className="mt-3 font-display text-4xl font-bold tabular-nums">
              {formatMinor(wallet?.ngnBalance ?? 0, "NGN")}
            </p>
            <div className="mt-4 flex items-center gap-3">
              <TopupButton currency="NGN" />
            </div>
          </section>
          <section className="relative overflow-hidden rounded-[1.75rem] border border-nafa-200 bg-nafa-50 p-6 shadow-card dark:border-nafa-400/20 dark:bg-nafa-400/5">
            <div className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full bg-nafa-400/20 blur-2xl" />
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-nafa-700/70 dark:text-nafa-300/70">
                <Flag code="BJ" className="h-4 w-6" /> Portefeuille CFA
              </span>
              <Wallet2 className="h-5 w-5 text-nafa-400/60" />
            </div>
            <p className="mt-3 font-display text-4xl font-bold tabular-nums text-nafa-800 dark:text-nafa-200">
              {formatMinor(wallet?.xofBalance ?? 0, "XOF")}
            </p>
            <div className="mt-4 flex items-center gap-3">
              <TopupButton currency="XOF" />
            </div>
          </section>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          {/* Historique */}
          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800">
            <h2 className="font-display text-lg font-bold">Transactions récentes</h2>
            {recent.length === 0 ? (
              <div className="py-10 text-center">
                <p className="text-sm font-bold text-slate-400">Aucun transfert pour le moment.</p>
                <Link href="/" className="btn-3d mt-4 inline-flex items-center gap-2 rounded-2xl bg-night-900 px-6 py-3 font-display font-bold text-white dark:bg-nafa-500 dark:text-night-950">
                  <Plus className="h-4 w-4" /> Envoyer mon premier transfert
                </Link>
              </div>
            ) : (
              <ul className="mt-3 divide-y divide-slate-100 dark:divide-white/5">
                {recent.map((tx) => {
                  const source = tx.direction === "NGN_XOF" ? "NGN" : "XOF";
                  const target = tx.direction === "NGN_XOF" ? "XOF" : "NGN";
                  return (
                    <li key={tx.trackingId}>
                      <Link href={`/tx/${tx.trackingId}`} className="flex items-center gap-3 py-3.5 transition hover:bg-slate-50/70 dark:hover:bg-white/[0.03]">
                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: tx.methodColor }}>
                          <ArrowUpRight className="h-4 w-4" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold text-slate-800 dark:text-slate-100">
                            {formatMinor(tx.sendAmount, source)} → {formatMinor(tx.receiveAmount, target)}
                          </p>
                          <p className="mt-0.5 flex items-center gap-2 text-xs font-semibold text-slate-400">
                            <DirectionChip direction={tx.direction} /> {tx.methodLabel} · {tx.countryTo}
                          </p>
                        </div>
                        <div className="flex shrink-0 flex-col items-end gap-1">
                          <StatusPill status={tx.status} />
                          <span className="text-[10px] font-bold text-slate-400">
                            {new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short" }).format(new Date(tx.createdAt))}
                          </span>
                        </div>
                        <ArrowRight className="h-4 w-4 shrink-0 text-slate-300" />
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          {/* Notifications */}
          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800">
            <h2 className="flex items-center gap-2 font-display text-lg font-bold">
              <Bell className="h-5 w-5 text-amber-500" /> Notifications
              {unread > 0 && (
                <span className="rounded-full bg-rose-500 px-2 py-0.5 text-xs font-bold text-white">{unread}</span>
              )}
            </h2>
            {notifs.length === 0 ? (
              <p className="py-8 text-center text-sm font-bold text-slate-400">Rien de nouveau.</p>
            ) : (
              <ul className="mt-3 space-y-2.5">
                {notifs.map((n) => (
                  <li key={n.id} className={`rounded-2xl p-3.5 text-sm ${n.readAt ? "bg-slate-50 dark:bg-night-850" : "bg-nafa-50 dark:bg-nafa-400/10"}`}>
                    <p className="font-bold text-slate-800 dark:text-slate-100">{n.title}</p>
                    <p className="mt-0.5 text-xs font-semibold leading-relaxed text-slate-500 dark:text-slate-400">{n.body}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
