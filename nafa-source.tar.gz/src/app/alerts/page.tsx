import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { rateAlerts, rates } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { appliedRate } from "@/lib/money";
import { getNavData } from "@/lib/nav-data";
import { Nav } from "@/components/nav";
import { AlertManager } from "@/components/alert-manager";
import { Bell } from "lucide-react";

export const metadata: Metadata = { title: "Alertes de taux" };
export const dynamic = "force-dynamic";

export default async function AlertsPage() {
  const session = await getSession();
  if (!session) redirect("/login?next=/alerts");
  const { user, unread } = await getNavData();

  const alerts = await db
    .select()
    .from(rateAlerts)
    .where(eq(rateAlerts.userId, session.sub))
    .orderBy(desc(rateAlerts.createdAt))
    .limit(30);
  const rateRows = await db.select().from(rates);
  const ratesApplied = rateRows.map((r) => ({
    kind: r.kind,
    applied: { NGN_XOF: appliedRate(r, "NGN_XOF"), XOF_NGN: appliedRate(r, "XOF_NGN") },
  }));

  return (
    <div className="pb-24 md:pb-0">
      <Nav user={user} unread={unread} />
      <main className="mx-auto max-w-2xl space-y-6 px-4 py-6">
        <div>
          <h1 className="flex items-center gap-2 font-display text-2xl font-bold sm:text-3xl">
            <Bell className="h-7 w-7 text-amber-500" /> Alertes de taux
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Sois notifié dès que le taux atteint ton seuil — les alertes sont
            évaluées à chaque mise à jour de cours.
          </p>
        </div>
        <AlertManager initial={alerts} ratesApplied={ratesApplied} />
      </main>
    </div>
  );
}
