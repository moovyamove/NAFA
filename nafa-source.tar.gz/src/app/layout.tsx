import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter, Sora } from "next/font/google";
import { ensureDatabase } from "@/lib/bootstrap";
import "./globals.css";

const sora = Sora({ subsets: ["latin"], variable: "--font-display" });
const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: {
    default: "NAFA — Envoi Naira ⇄ CFA, simple et transparent",
    template: "%s · NAFA",
  },
  description:
    "Échangez des Nairas (NGN) vers la zone CFA UEMOA (XOF) en quelques secondes : taux officiel ou parallèle, frais transparents, Wave, MTN MoMo, Orange Money, OPay, Kuda, PalmPay et virements bancaires.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "NAFA", statusBarStyle: "default" },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f4f6fb" },
    { media: "(prefers-color-scheme: dark)", color: "#0a1120" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

const THEME_INIT = `(function(){try{var t=localStorage.getItem('nafa-theme');var d=t?t==='dark':window.matchMedia('(prefers-color-scheme: dark)').matches;if(d)document.documentElement.classList.add('dark');}catch(e){}})()`;

export default async function RootLayout({ children }: { children: ReactNode }) {
  await ensureDatabase();
  return (
    <html lang="fr" className={`${sora.variable} ${inter.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT }} />
      </head>
      <body className="min-h-dvh bg-[#f4f6fb] font-sans text-slate-800 antialiased dark:bg-night-900 dark:text-slate-100">
        {children}
      </body>
    </html>
  );
}
