import { NextResponse } from "next/server";
import { db } from "@/db";
import { rateAlerts } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

type Params = { params: Promise<{ id: string }> };

export async function DELETE(_req: Request, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const { id } = await params;
  await db
    .update(rateAlerts)
    .set({ isActive: false })
    .where(and(eq(rateAlerts.id, id), eq(rateAlerts.userId, session.sub)));
  return NextResponse.json({ ok: true });
}
