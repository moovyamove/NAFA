import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { rateAlerts, rates } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { getSession, rateLimit } from "@/lib/auth";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const rows = await db
    .select()
    .from(rateAlerts)
    .where(eq(rateAlerts.userId, session.sub))
    .orderBy(desc(rateAlerts.createdAt))
    .limit(30);
  return NextResponse.json({ alerts: rows });
}

const schema = z.object({
  direction: z.enum(["NGN_XOF", "XOF_NGN"]),
  rateKind: z.enum(["official", "parallel"]),
  threshold: z.number().positive().max(100),
  above: z.boolean(),
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  if (!rateLimit(`alerts:${session.sub}`, 20, 60_000).ok) {
    return NextResponse.json({ error: "Trop de requêtes." }, { status: 429 });
  }
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Seuil invalide" }, { status: 400 });
  }

  const count = await db
    .select({ id: rateAlerts.id })
    .from(rateAlerts)
    .where(and(eq(rateAlerts.userId, session.sub), eq(rateAlerts.isActive, true)));
  if (count.length >= 10) {
    return NextResponse.json({ error: "Maximum 10 alertes actives." }, { status: 400 });
  }

  // Évite les doublons exacts
  const d = parsed.data;
  const existing = await db
    .select({ id: rateAlerts.id })
    .from(rateAlerts)
    .where(
      and(
        eq(rateAlerts.userId, session.sub),
        eq(rateAlerts.direction, d.direction),
        eq(rateAlerts.rateKind, d.rateKind),
      ),
    );
  for (const e of existing) {
    const [row] = await db.select().from(rateAlerts).where(eq(rateAlerts.id, e.id)).limit(1);
    if (row && Number(row.threshold) === d.threshold && row.above === d.above && row.isActive) {
      return NextResponse.json({ error: "Cette alerte existe déjà." }, { status: 409 });
    }
  }

  await db.insert(rateAlerts).values({
    userId: session.sub,
    direction: d.direction,
    rateKind: d.rateKind,
    threshold: String(d.threshold),
    above: d.above,
  });
  void rates;
  return NextResponse.json({ ok: true });
}
