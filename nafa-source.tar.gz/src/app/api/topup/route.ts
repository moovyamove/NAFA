import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { wallets, activityLogs } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getSession, rateLimit } from "@/lib/auth";

const schema = z.object({ currency: z.enum(["NGN", "XOF"]) });

/** Recharge instantanée du portefeuille — fonction de DÉMO (aucun vrai flux
 *  d'argent ne circule dans cette application de démonstration). */
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  if (!rateLimit(`topup:${session.sub}`, 20, 60_000).ok) {
    return NextResponse.json({ error: "Trop de recharges." }, { status: 429 });
  }
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Devise invalide" }, { status: 400 });

  const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, session.sub)).limit(1);
  if (!wallet) return NextResponse.json({ error: "Portefeuille introuvable" }, { status: 404 });

  if (parsed.data.currency === "NGN") {
    await db.update(wallets).set({
      ngnBalance: sql`${wallets.ngnBalance} + 10000000`, // +₦100 000
      updatedAt: new Date(),
    }).where(eq(wallets.userId, session.sub));
  } else {
    await db.update(wallets).set({
      xofBalance: sql`${wallets.xofBalance} + 30000000`, // +300 000 F
      updatedAt: new Date(),
    }).where(eq(wallets.userId, session.sub));
  }
  await db.insert(activityLogs).values({
    userId: session.sub,
    action: "demo_topup",
    meta: parsed.data.currency,
  });
  return NextResponse.json({ ok: true });
}
