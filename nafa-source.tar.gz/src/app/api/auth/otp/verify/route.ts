import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import crypto from "node:crypto";
import { db } from "@/db";
import { otpCodes, users, wallets, activityLogs } from "@/db/schema";
import { and, eq, gt, isNull, desc } from "drizzle-orm";
import { createSession, rateLimit } from "@/lib/auth";

const schema = z.object({
  phone: z.string().trim().regex(/^\+?\d{8,15}$/),
  code: z.string().trim().regex(/^\d{6}$/, "Le code fait 6 chiffres"),
  name: z.string().trim().min(2).max(80).optional(),
});

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "anon";
  if (!rateLimit(`otp-verify:${ip}`, 120, 300_000).ok) {
    return NextResponse.json({ error: "Trop de requêtes." }, { status: 429 });
  }
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Code invalide." }, { status: 400 });
  }
  const phone = parsed.data.phone.startsWith("+") ? parsed.data.phone : `+${parsed.data.phone}`;

  const codeHash = crypto.createHash("sha256").update(parsed.data.code).digest("hex");
  const [row] = await db
    .select()
    .from(otpCodes)
    .where(
      and(
        eq(otpCodes.phone, phone),
        eq(otpCodes.codeHash, codeHash),
        gt(otpCodes.expiresAt, new Date()),
        isNull(otpCodes.usedAt),
      ),
    )
    .orderBy(desc(otpCodes.createdAt))
    .limit(1);

  if (!row) {
    return NextResponse.json(
      { error: "Code incorrect ou expiré. Redemande un nouveau code." },
      { status: 401 },
    );
  }
  await db.update(otpCodes).set({ usedAt: new Date() }).where(eq(otpCodes.id, row.id));

  // Connexion ou création du compte
  let [user] = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
  if (!user) {
    const name = parsed.data.name?.trim();
    if (!name || name.length < 2) {
      return NextResponse.json({ needName: true }, { status: 428 });
    }
    [user] = await db.insert(users).values({ phone, name, role: "USER" }).returning();
    await db.insert(wallets).values({ userId: user.id });
    await db.insert(activityLogs).values({ userId: user.id, action: "account_created" });
  }

  await createSession(user.id, user.role);
  return NextResponse.json({
    ok: true,
    user: { id: user.id, phone: user.phone, name: user.name, role: user.role },
  });
}
