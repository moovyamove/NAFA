import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import crypto from "node:crypto";
import { db } from "@/db";
import { otpCodes } from "@/db/schema";
import { rateLimit } from "@/lib/auth";

const schema = z.object({
  phone: z
    .string()
    .trim()
    .regex(/^\+?\d{8,15}$/, "Numéro invalide (format international attendu, ex. +22997000000)"),
});

/**
 * Demande d'OTP. Sans fournisseur SMS configuré (SMS_API_KEY), le code est
 * renvoyé dans la réponse pour la démo — brancher un provider (Twilio,
 * Africa's Talking…) en production et retirer ce renvoi.
 */
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "anon";
  if (!rateLimit(`otp-ip:${ip}`, 60, 300_000).ok) {
    return NextResponse.json({ error: "Trop de requêtes." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Numéro invalide" },
      { status: 400 },
    );
  }
  const phone = parsed.data.phone.startsWith("+") ? parsed.data.phone : `+${parsed.data.phone}`;

  if (!rateLimit(`otp:${phone}`, 4, 600_000).ok) {
    return NextResponse.json(
      { error: "Trop de codes demandés. Réessaie dans 10 minutes." },
      { status: 429 },
    );
  }

  const code = String(crypto.randomInt(100000, 999999));
  const codeHash = crypto.createHash("sha256").update(code).digest("hex");
  await db.insert(otpCodes).values({
    phone,
    codeHash,
    expiresAt: new Date(Date.now() + 10 * 60_000),
  });

  // TODO(prod): envoyer le code par SMS au lieu de le renvoyer.
  if (!process.env.SMS_API_KEY) {
    return NextResponse.json({ ok: true, devCode: code, phone });
  }
  return NextResponse.json({ ok: true, phone });
}
