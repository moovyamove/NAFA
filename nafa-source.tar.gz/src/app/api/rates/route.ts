import { NextResponse } from "next/server";
import { db } from "@/db";
import { payoutMethods, rates } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { appliedRate } from "@/lib/money";

/** Données publiques du convertisseur : taux (avec marge appliquée) + méthodes. */
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(rates);
  const methods = await db
    .select()
    .from(payoutMethods)
    .where(eq(payoutMethods.isActive, true))
    .orderBy(asc(payoutMethods.sortOrder));

  const rateOut = rows.map((r) => ({
    kind: r.kind,
    source: r.source,
    updatedAt: r.updatedAt,
    marginPercent: Number(r.marginPercent),
    base: { NGN_XOF: Number(r.ngnToXof), XOF_NGN: Number(r.xofToNgn) },
    applied: {
      NGN_XOF: appliedRate(r, "NGN_XOF"),
      XOF_NGN: appliedRate(r, "XOF_NGN"),
    },
  }));

  return NextResponse.json({ rates: rateOut, methods });
}
