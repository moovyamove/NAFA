import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications, payoutMethods, transactions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

type Params = { params: Promise<{ id: string }> };

const STAGES = [
  { atSeconds: 0, status: "pending" as const, label: "En attente", detail: "Transfert reçu et vérifié." },
  { atSeconds: 12, status: "processing" as const, label: "En cours", detail: "Fonds acheminés vers le partenaire de réception." },
  { atSeconds: 40, status: "success" as const, label: "Réussi", detail: "Bénéficiaire crédité." },
];

/** Suivi d'une transaction (par trackingId, propriétaire ou admin). Le statut
 *  progresse automatiquement avec le temps pour la démo. */
export async function GET(_req: Request, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const { id } = await params;

  const [row] = await db
    .select({ tx: transactions, method: payoutMethods })
    .from(transactions)
    .innerJoin(payoutMethods, eq(transactions.methodId, payoutMethods.id))
    .where(eq(transactions.trackingId, id))
    .limit(1);
  if (!row) return NextResponse.json({ error: "Transaction introuvable" }, { status: 404 });
  if (row.tx.senderId !== session.sub && session.role !== "ADMIN") {
    return NextResponse.json({ error: "Transaction introuvable" }, { status: 404 });
  }

  let status = row.tx.status;
  // Progression simulée : jamais en arrière, jamais sur un statut final
  // — les décisions de l'admin (success/failed manuels) sont souveraines.
  const RANK: Record<string, number> = { pending: 0, processing: 1, success: 2, failed: 9 };
  const CURRENT_RANK = RANK[status] ?? 0;
  if (CURRENT_RANK < RANK.success) {
    const age = (Date.now() - new Date(row.tx.createdAt).getTime()) / 1000;
    const stage = [...STAGES].reverse().find((s) => age >= s.atSeconds) ?? STAGES[0];
    if ((RANK[stage.status] ?? 0) > CURRENT_RANK) {
      status = stage.status;
      await db
        .update(transactions)
        .set({ status, updatedAt: new Date() })
        .where(and(eq(transactions.id, row.tx.id)));
      if (status === "success") {
        await db.insert(notifications).values({
          userId: row.tx.senderId,
          title: "Transfert réussi",
          body: `${row.tx.trackingId} crédité sur ${row.method.label}.`,
        });
      }
    }
  }

  const age = Math.max(0, Math.floor((Date.now() - new Date(row.tx.createdAt).getTime()) / 1000));
  return NextResponse.json({
    transaction: {
      trackingId: row.tx.trackingId,
      direction: row.tx.direction,
      status,
      sendAmount: row.tx.sendAmount,
      feeAmount: row.tx.feeAmount,
      receiveAmount: row.tx.receiveAmount,
      rateApplied: Number(row.tx.rateApplied),
      rateKind: row.tx.rateKind,
      countryFrom: row.tx.countryFrom,
      countryTo: row.tx.countryTo,
      beneficiaryName: row.tx.beneficiaryName,
      beneficiaryAccount: row.tx.beneficiaryAccount,
      method: { label: row.method.label, color: row.method.color, etaLabel: row.method.etaLabel, accountHint: row.method.accountHint },
      createdAt: row.tx.createdAt,
      ageSeconds: age,
      stages: STAGES,
    },
  });
}
