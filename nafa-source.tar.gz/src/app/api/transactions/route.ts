import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import {
  activityLogs,
  notifications,
  payoutMethods,
  rates,
  transactions,
  wallets,
} from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { getSession, rateLimit } from "@/lib/auth";
import {
  computeQuote,
  directionMeta,
  makeTrackingId,
  majorToMinor,
  minorToMajor,
  type Currency,
} from "@/lib/money";

const schema = z.object({
  direction: z.enum(["NGN_XOF", "XOF_NGN"]),
  rateKind: z.enum(["official", "parallel"]),
  methodId: z.string().uuid(),
  sendAmount: z.number().positive().max(100_000_000),
  countryFrom: z.string().min(2).max(40),
  countryTo: z.string().min(2).max(40),
  beneficiaryName: z.string().trim().min(2).max(90),
  beneficiaryAccount: z.string().trim().min(8).max(34).regex(/^[0-9A-Z\s-]+$/i, "Format de compte invalide"),
});

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const rows = await db
    .select({
      trackingId: transactions.trackingId,
      direction: transactions.direction,
      status: transactions.status,
      sendAmount: transactions.sendAmount,
      receiveAmount: transactions.receiveAmount,
      rateApplied: transactions.rateApplied,
      countryTo: transactions.countryTo,
      methodLabel: payoutMethods.label,
      methodColor: payoutMethods.color,
      createdAt: transactions.createdAt,
    })
    .from(transactions)
    .innerJoin(payoutMethods, eq(transactions.methodId, payoutMethods.id))
    .where(eq(transactions.senderId, session.sub))
    .orderBy(desc(transactions.createdAt))
    .limit(25);
  return NextResponse.json({ transactions: rows });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Connecte-toi pour envoyer." }, { status: 401 });
  if (!rateLimit(`tx:${session.sub}`, 10, 60_000).ok) {
    return NextResponse.json({ error: "Doucement… réessaie dans une minute." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Données invalides" },
      { status: 400 },
    );
  }
  const d = parsed.data;
  const { source, target } = directionMeta(d.direction);

  const [method] = await db.select().from(payoutMethods).where(eq(payoutMethods.id, d.methodId)).limit(1);
  if (!method || !method.isActive) {
    return NextResponse.json({ error: "Méthode de réception indisponible." }, { status: 400 });
  }
  // La méthode doit correspondre à la devise reçue
  if (method.zone !== target) {
    return NextResponse.json({ error: "Méthode incompatible avec cette direction." }, { status: 400 });
  }

  const [rate] = await db.select().from(rates).where(eq(rates.kind, d.rateKind)).limit(1);
  if (!rate) return NextResponse.json({ error: "Taux indisponible." }, { status: 503 });

  const sendMinor = majorToMinor(d.sendAmount, source);
  const MIN: Record<Currency, number> = { NGN: 100_000, XOF: 500_000 }; // ₦1 000 · 5 000 F
  if (sendMinor < MIN[source]) {
    return NextResponse.json(
      { error: `Montant minimum : ${source === "NGN" ? "₦1 000" : "5 000 F CFA"}.` },
      { status: 400 },
    );
  }

  // Recalcul AUTORITAIRE côté serveur
  const quote = computeQuote({ direction: d.direction, rateKind: d.rateKind, sendMinor, rate, method });
  if (quote.receiveAmount <= 0) {
    return NextResponse.json({ error: "Montant trop faible après frais." }, { status: 400 });
  }

  const trackingId = makeTrackingId();
  try {
    await db.transaction(async (tx) => {
      await tx.insert(transactions).values({
        trackingId,
        senderId: session.sub,
        methodId: method.id,
        direction: d.direction,
        rateKind: d.rateKind,
        rateApplied: String(quote.rate),
        countryFrom: d.countryFrom,
        countryTo: d.countryTo,
        beneficiaryName: d.beneficiaryName,
        beneficiaryAccount: d.beneficiaryAccount,
        sendAmount: quote.sendAmount,
        feeAmount: quote.feeAmount,
        receiveAmount: quote.receiveAmount,
        status: "pending",
      });

      if (source === "NGN") {
        const res = await tx
          .update(wallets)
          .set({ ngnBalance: sql`${wallets.ngnBalance} - ${quote.sendAmount}`, updatedAt: new Date() })
          .where(and(eq(wallets.userId, session.sub), sql`${wallets.ngnBalance} >= ${quote.sendAmount}`))
          .returning({ id: wallets.id });
        if (!res[0]) throw new Error("insufficient_funds");
      } else {
        const res = await tx
          .update(wallets)
          .set({ xofBalance: sql`${wallets.xofBalance} - ${quote.sendAmount}`, updatedAt: new Date() })
          .where(and(eq(wallets.userId, session.sub), sql`${wallets.xofBalance} >= ${quote.sendAmount}`))
          .returning({ id: wallets.id });
        if (!res[0]) throw new Error("insufficient_funds");
      }
    });
  } catch (err) {
    if (err instanceof Error && err.message === "insufficient_funds") {
      return NextResponse.json(
        {
          error: `Solde insuffisant. Recharge ton portefeuille ${source} (bouton « Recharger » du tableau de bord — instantané en démo).`,
          code: "insufficient_funds",
        },
        { status: 402 },
      );
    }
    throw err;
  }

  await db.insert(notifications).values({
    userId: session.sub,
    title: "Transfert créé",
    body: `${trackingId} — ${d.countryTo}, ${method.label}.`,
  });
  await db.insert(activityLogs).values({
    userId: session.sub,
    action: "tx_created",
    meta: JSON.stringify({ trackingId, amount: minorToMajor(quote.sendAmount), currency: source }),
  });

  return NextResponse.json({ ok: true, trackingId, target });
}
