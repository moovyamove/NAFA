import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { activityLogs, notifications, rateAlerts, rates, type Rate } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { appliedRate, type Direction, type RateKind } from "@/lib/money";

const updateSchema = z.object({
  kind: z.enum(["official", "parallel"]),
  ngnToXof: z.number().positive().max(10),
  xofToNgn: z.number().positive().max(10),
  marginPercent: z.number().min(0).max(15),
});

/** Après chaque mise à jour de taux : déclenche les alertes franchies. */
async function evaluateAlerts(updatedKind: RateKind, rateRow: Rate) {
  const actives = await db
    .select()
    .from(rateAlerts)
    .where(eq(rateAlerts.isActive, true));
  for (const alert of actives) {
    if (alert.rateKind !== updatedKind) continue;
    const applied = appliedRate(rateRow, alert.direction as Direction);
    const threshold = Number(alert.threshold);
    const crossed = alert.above ? applied >= threshold : applied <= threshold;
    if (!crossed) continue;
    await db
      .update(rateAlerts)
      .set({ isActive: false, triggeredAt: new Date() })
      .where(eq(rateAlerts.id, alert.id));
    const pretty =
      alert.direction === "NGN_XOF"
        ? `1 ₦ = ${applied.toFixed(4)} F CFA`
        : `1 F CFA = ${applied.toFixed(3)} ₦`;
    await db.insert(notifications).values({
      userId: alert.userId,
      title: "Alerte de taux atteinte",
      body: `Le taux ${updatedKind === "official" ? "officiel" : "parallèle"} vaut maintenant ${pretty} (seuil : ${alert.above ? "≥" : "≤"} ${threshold}).`,
    });
  }
}

async function requireAdmin() {
  const session = await getSession();
  return session?.role === "ADMIN" ? session : null;
}

export async function PUT(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Valeurs de taux invalides." }, { status: 400 });
  }
  const d = parsed.data;
  const [row] = await db
    .update(rates)
    .set({
      ngnToXof: String(d.ngnToXof),
      xofToNgn: String(d.xofToNgn),
      marginPercent: String(d.marginPercent),
      source: "manual",
      updatedAt: new Date(),
    })
    .where(eq(rates.kind, d.kind))
    .returning();
  await db.insert(activityLogs).values({
    userId: session.sub,
    action: "rate_updated",
    meta: JSON.stringify({ kind: d.kind, ngnToXof: d.ngnToXof }),
  });
  await evaluateAlerts(d.kind, row);
  return NextResponse.json({ ok: true });
}

/** Récupère le cours depuis une API publique (sans clé). Échec → erreur propre,
 *  le taux manuel reste la référence. */
export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });

  const body = (await req.json().catch(() => ({}))) as { action?: string };
  if (body.action !== "refresh") {
    return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch("https://open.er-api.com/v6/latest/NGN", {
      signal: controller.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = (await res.json()) as { rates?: Record<string, number> };
    const xofPerNgn = data.rates?.XOF;
    if (!xofPerNgn || xofPerNgn <= 0) throw new Error("XOF absent de la réponse");

    const ngnToXof = Math.round(xofPerNgn * 1_000_000) / 1_000_000;
    const xofToNgn = Math.round((1 / xofPerNgn) * 1_000_000) / 1_000_000;
    const [row] = await db
      .update(rates)
      .set({
        ngnToXof: String(ngnToXof),
        xofToNgn: String(xofToNgn),
        source: "open.er-api.com",
        updatedAt: new Date(),
      })
      .where(eq(rates.kind, "official"))
      .returning();
    await db.insert(activityLogs).values({
      userId: session.sub,
      action: "rate_refreshed",
      meta: JSON.stringify({ ngnToXof }),
    });
    await evaluateAlerts("official", row);
    return NextResponse.json({ ok: true, ngnToXof, xofToNgn, source: "open.er-api.com" });
  } catch (err) {
    return NextResponse.json(
      {
        error: "API de taux injoignable pour le moment — le taux manuel reste appliqué.",
        detail: err instanceof Error ? err.message.slice(0, 120) : undefined,
      },
      { status: 502 },
    );
  }
}
