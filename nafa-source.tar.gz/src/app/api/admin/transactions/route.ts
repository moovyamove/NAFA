import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { activityLogs, notifications, transactions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

const schema = z.object({
  trackingId: z.string().min(8).max(24),
  status: z.enum(["pending", "processing", "success", "failed"]),
});

const STATUS_LABELS: Record<string, string> = {
  pending: "en attente",
  processing: "en cours de traitement",
  success: "marquée comme réussie",
  failed: "marquée comme échouée",
};

export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (session?.role !== "ADMIN") {
    return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  }
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Données invalides" }, { status: 400 });
  }

  const [tx] = await db
    .update(transactions)
    .set({ status: parsed.data.status, updatedAt: new Date() })
    .where(eq(transactions.trackingId, parsed.data.trackingId))
    .returning();
  if (!tx) return NextResponse.json({ error: "Transaction introuvable" }, { status: 404 });

  await db.insert(notifications).values({
    userId: tx.senderId,
    title: "Mise à jour de transfert",
    body: `${tx.trackingId} ${STATUS_LABELS[parsed.data.status]}.`,
  });
  await db.insert(activityLogs).values({
    userId: session.sub,
    action: "tx_status_set",
    meta: JSON.stringify({ trackingId: tx.trackingId, status: parsed.data.status }),
  });
  return NextResponse.json({ ok: true });
}
