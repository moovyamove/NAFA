import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { TxTracker } from "@/components/tx-tracker";
import { Nav } from "@/components/nav";
import { getNavData } from "@/lib/nav-data";

export const metadata: Metadata = { title: "Suivi de transfert" };
export const dynamic = "force-dynamic";

export default async function TxPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  const { id } = await params;
  if (!session) redirect(`/login?next=/tx/${id}`);
  const { user, unread } = await getNavData();

  return (
    <div className="pb-24 md:pb-0">
      <Nav user={user} unread={unread} />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <TxTracker trackingId={id} />
      </main>
    </div>
  );
}
