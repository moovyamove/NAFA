import Link from "next/link";
import {
  ArrowRight, Bell, Globe2, Landmark, Lock, ShieldCheck, Smartphone, TrendingUp, Wallet2, Zap,
} from "lucide-react";
import { Converter } from "@/components/converter";
import { Flag, NIGERIA, TrustBadge, UEMOA } from "@/components/flags";
import { Nav } from "@/components/nav";
import { getNavData } from "@/lib/nav-data";

export const dynamic = "force-dynamic";

const ZONE_LABELS = [
  { zone: "XOF" as const, title: "Réception en francs CFA", methods: ["Wave", "MTN MoMo", "Orange Money", "Moov Money", "Virement UEMOA"], colors: ["#1dc4e9", "#ffcc00", "#ff7900", "#0066b3", "#475569"] },
  { zone: "NG" as const, title: "Réception en naira", methods: ["Transfert bancaire", "Kuda", "OPay", "PalmPay"], colors: ["#005baa", "#40196d", "#00b48b", "#6c2bd9"] },
];

export default async function HomePage() {
  const { user, unread } = await getNavData();

  return (
    <div className="pb-24 md:pb-0">
      <Nav user={user} unread={unread} />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_60%_at_50%_-10%,rgba(16,185,129,0.14),transparent_70%)]" />
        <div className="mx-auto grid max-w-5xl items-center gap-10 px-4 pb-16 pt-10 lg:grid-cols-[1fr_1.1fr] lg:pt-16">
          <div className="relative z-10">
            <span className="inline-flex items-center gap-2 rounded-full border border-nafa-200 bg-nafa-50 px-4 py-1.5 text-xs font-bold text-nafa-700 dark:border-nafa-400/30 dark:bg-nafa-400/10 dark:text-nafa-300">
              <Zap className="h-3.5 w-3.5" /> Transferts Nigeria ⇄ UEMOA
            </span>
            <h1 className="mt-5 font-display text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl">
              Envoie des Nairas.
              <span className="bg-gradient-to-r from-nafa-500 to-teal-500 bg-clip-text text-transparent"> Ils reçoivent des CFA.</span>
            </h1>
            <p className="mt-4 max-w-md text-lg leading-relaxed text-slate-500 dark:text-slate-400">
              Wave, MTN MoMo, Orange Money au sud — Kuda, OPay, PalmPay au nord.
              Deux marchés de taux, zéro frais caché, suivi en direct.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <TrustBadge>Frais transparents</TrustBadge>
              <TrustBadge>ID de suivi unique</TrustBadge>
              <TrustBadge>Sessions chiffrées</TrustBadge>
            </div>
            <div className="mt-8 hidden items-center gap-4 text-sm font-bold text-slate-400 dark:text-slate-500 lg:flex">
              <span className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-nafa-500" /> Simulation libre
              </span>
              <span>Compte en 30 s au moment de l'envoi</span>
            </div>
          </div>
          <Converter user={user} />
        </div>
      </section>

      {/* Bandeau drapeaux */}
      <section className="border-y border-slate-200/70 bg-white/60 py-4 dark:border-white/10 dark:bg-night-850/60">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-center gap-x-6 gap-y-2 px-4">
          <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-400">
            <Flag code="NG" className="h-4 w-6" /> Nigeria
          </span>
          <span className="text-slate-300 dark:text-slate-600">⇄</span>
          {UEMOA.map((c) => (
            <span key={c.code} className="flex items-center gap-1.5 text-xs font-bold text-slate-500 dark:text-slate-400" title={c.name}>
              <Flag code={c.code} className="h-4 w-6" />
              <span className="hidden sm:inline">{c.code}</span>
            </span>
          ))}
        </div>
      </section>

      {/* Méthodes */}
      <section className="mx-auto max-w-5xl px-4 py-14">
        <h2 className="text-center font-display text-2xl font-bold sm:text-3xl">
          Reçu là où l'argent vit
        </h2>
        <p className="mx-auto mt-2 max-w-lg text-center text-slate-500 dark:text-slate-400">
          Mobile money pour l'instantané, banque pour les gros montants.
        </p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {ZONE_LABELS.map((z) => (
            <div key={z.zone} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800">
              <h3 className="flex items-center gap-2 font-display text-lg font-bold">
                {z.zone === "NG" ? <Landmark className="h-5 w-5 text-nafa-500" /> : <Smartphone className="h-5 w-5 text-nafa-500" />}
                {z.title}
              </h3>
              <div className="mt-4 flex flex-wrap gap-2">
                {z.methods.map((m, i) => (
                  <span key={m} className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-sm font-bold text-slate-600 dark:border-white/10 dark:text-slate-300">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: z.colors[i] }} />
                    {m}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Taux officiel vs parallèle */}
      <section className="mx-auto max-w-5xl px-4 pb-14">
        <div className="grid items-center gap-8 rounded-[2rem] bg-night-900 p-8 shadow-deep dark:bg-night-800 md:grid-cols-[1.2fr_1fr] md:p-12">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-nafa-400/10 px-3 py-1 text-xs font-bold text-nafa-300">
              <TrendingUp className="h-3.5 w-3.5" /> Spécial Naira
            </span>
            <h2 className="mt-4 font-display text-2xl font-bold text-white sm:text-3xl">
              Officiel ou parallèle : tu choisis ton marché
            </h2>
            <p className="mt-3 leading-relaxed text-slate-300">
              Au Nigeria, deux cours cohabitent. NAFA affiche les deux —
              avant la moindre confirmation — avec la marge exacte incluse
              dans le calcul. Pas de mauvaise surprise au crédit.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Link href="/rates" className="btn-3d inline-flex items-center gap-1.5 rounded-2xl bg-white/10 px-5 py-3 font-display font-bold text-white hover:bg-white/15">
                Voir les cours <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/alerts" className="btn-3d inline-flex items-center gap-1.5 rounded-2xl border border-white/15 px-5 py-3 font-display font-bold text-nafa-300 hover:bg-white/5">
                <Bell className="h-4 w-4" /> Créer une alerte de taux
              </Link>
            </div>
          </div>
          <div className="space-y-3">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="text-xs font-bold uppercase tracking-wide text-slate-400">Exemple — 50 000 ₦ → Bénin</p>
              <p className="mt-1 font-display text-2xl font-bold text-white">Taux officiel : ≈ 18 625 F</p>
              <p className="text-xs font-semibold text-slate-400">1 ₦ = 0,3825 F · marge 1 %</p>
            </div>
            <div className="rounded-2xl border border-nafa-400/30 bg-nafa-400/10 p-4">
              <p className="text-xs font-bold uppercase tracking-wide text-nafa-300">Même 50 000 ₦, marché parallèle</p>
              <p className="mt-1 font-display text-2xl font-bold text-nafa-300">≈ 21 900 F <span className="rounded-full bg-nafa-400 px-2 py-0.5 align-middle text-xs font-black text-night-950">+17 %</span></p>
              <p className="text-xs font-semibold text-nafa-300/70">1 ₦ = 0,4452 F · marge 1,5 %</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white dark:border-white/10 dark:bg-night-900">
        <div className="mx-auto flex max-w-5xl flex-col items-center gap-4 px-4 py-8 text-center">
          <span className="flex items-center gap-2 font-display font-bold">
            <Globe2 className="h-4 w-4 text-nafa-500" /> NAFA — West Africa Exchange
          </span>
          <p className="max-w-xl text-xs leading-relaxed text-slate-400">
            Application de démonstration. Aucun transfert d'argent réel n'est
            exécuté. Les cours affichés sont indicatifs et ne constituent pas
            une offre de change au sens réglementaire. Un module KYC est prévu
            dans la feuille de route avant tout lancement réel.
          </p>
          <nav className="flex items-center gap-5 text-xs font-bold text-slate-500">
            <Link href="/rates" className="hover:text-nafa-600">Cours du jour</Link>
            <Link href="/dashboard" className="hover:text-nafa-600">Tableau de bord</Link>
            <span className="inline-flex items-center gap-1"><Lock className="h-3 w-3" /> Données chiffrées</span>
          </nav>
        </div>
      </footer>
    </div>
  );
}
