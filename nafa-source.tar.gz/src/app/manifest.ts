import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "NAFA — Envoi Naira ⇄ CFA",
    short_name: "NAFA",
    description:
      "Échangez NGN vers la zone CFA UEMOA avec taux officiel ou parallèle, frais transparents et réception mobile money instantanée.",
    start_url: "/",
    display: "standalone",
    background_color: "#0a1120",
    theme_color: "#10b981",
    lang: "fr",
    icons: [{ src: "/icon.png", sizes: "512x512", type: "image/png", purpose: "any" }],
  };
}
