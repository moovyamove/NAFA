import type { Metadata } from "next";
import { db } from "@/db";
import { rates } from "@/db/schema";
import { appliedRate, formatRate } from "@/lib/money";
import { getNavData } from "@/lib/nav-data";
import { Nav } from "@/components/nav";
import { LineChart, TrendingUp, Zap, Info } from "lucide-react";
import { cn } from "@/lib/cn";

export const metadata: Metadata = { title: "Cours du jour" };
export const dynamic = "force-dynamic";

export default async function RatesPage() {
  const { user, unread } = await getNavData();
  const rows = await db.select().from(rates);
  const official = rows.find((r) => r.kind === "official");
  const parallel = rows.find((r) => r.kind === "parallel");

  const spread =
    official && parallel
      ? ((appliedRate(parallel, "NGN_XOF") - appliedRate(official, "NGN_XOF")) /
          appliedRate(official, "NGN_XOF")) * 100
      : 0;

  return (
    <div className="pb-24 md:pb-0">
      <Nav user={user} unread={unread} />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        <h1 className="flex items-center gap-2 font-display text-2xl font-bold sm:text-3xl">
          <LineChart className="h-7 w-7 text-nafa-500" /> Cours du jour
        </h1>

        <div className="grid gap-4 sm:grid-cols-2">
          {rows.map((r) => (
            <section key={r.kind} className={cn(
              "rounded-3xl border-2 p-6 shadow-card",
              r.kind === "parallel"
                ? "border-nafa-400/60 bg-gradient-to-br from-nafa-50 to-white dark:border-nafa-400/30 dark:from-nafa-400/5 dark:to-night-800"
                : "border-slate-200 bg-white dark:border-white/10 dark:bg-night-800",
            )}>
              <div className="flex items-center justify-between">
                <span className={cn("flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide", r.kind === "parallel" ? "text-nafa-600 dark:text-nafa-300" : "text-slate-400")}>
                  {r.kind === "parallel" ? <TrendingUp className="h-3.5 w-3.5" /> : <Zap className="h-3.5 w-3.5" />}
                  {r.kind === "parallel" ? "Marché parallèle" : "Taux officiel"}
                </span>
                <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-300">
                  marge {Number(r.marginPercent)} %
                </span>
              </div>
              <dl className="mt-4 space-y-3">
                <div>
                  <dt className="text-xs font-semibold text-slate-400">1 ₦ =</dt>
                  <dd className="font-display text-3xl font-bold tabular-nums">
                    {formatRate(appliedRate(r, "NGN_XOF"), "NGN_XOF")} F CFA
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-semibold text-slate-400">1 F CFA =</dt>
                  <dd className="font-display text-xl font-bold tabular-nums text-slate-600 dark:text-slate-300">
                    {formatRate(appliedRate(r, "XOF_NGN"), "XOF_NGN")} ₦
                  </dd>
                </div>
              </dl>
              <p className="mt-4 text-[11px] font-semibold text-slate-400">
                Source : {r.source} · mis à jour le {new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" }).format(new Date(r.updatedAt))}
              </p>
            </section>
          ))}
        </div>

        {official && parallel && (
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-card dark:border-white/10 dark:bg-night-800">
            <p className="flex items-start gap-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-nafa-500" />
              Écart entre les deux marchés : <strong>+{spread.toFixed(1)} %</strong> en faveur du
              marché parallèle aujourd'hui. Cet écart varie chaque jour — crée
              une alerte de taux pour être prévenu dès qu'il devient intéressant.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
