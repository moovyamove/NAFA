import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { SendWizard } from "@/components/send-wizard";
import { Nav } from "@/components/nav";
import { getNavData } from "@/lib/nav-data";

export const metadata: Metadata = { title: "Envoyer de l'argent" };
export const dynamic = "force-dynamic";

export default async function SendPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string>>;
}) {
  const session = await getSession();
  const params = await searchParams;
  if (!session) {
    const qs = new URLSearchParams(params).toString();
    redirect(`/login?next=${encodeURIComponent(`/send?${qs}`)}`);
  }
  const { user, unread } = await getNavData();

  return (
    <div className="pb-24 md:pb-0">
      <Nav user={user} unread={unread} />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <Suspense>
          <SendWizard />
        </Suspense>
      </main>
    </div>
  );
}
