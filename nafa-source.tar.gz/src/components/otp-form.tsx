"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState, type FormEvent } from "react";
import { ArrowRight, Loader2, MessageSquareLock, ShieldCheck } from "lucide-react";
import { Logo } from "./flags";

type Step = "phone" | "code" | "name";

export function OtpForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") ?? "/dashboard";

  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const input =
    "w-full rounded-2xl border-2 border-slate-200 bg-slate-50/60 px-5 py-4 font-display text-lg font-bold text-slate-800 placeholder:font-sans placeholder:text-sm placeholder:font-normal placeholder:text-slate-400 focus:border-nafa-400 focus:bg-white focus:outline-none dark:border-white/10 dark:bg-night-850 dark:text-slate-100";

  async function requestCode(e?: FormEvent) {
    e?.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/otp/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.replace(/\s/g, "") }),
      });
      const data = (await res.json()) as { error?: string; devCode?: string };
      if (!res.ok) {
        setError(data.error ?? "Impossible d'envoyer le code.");
        return;
      }
      setDevCode(data.devCode ?? null);
      setStep("code");
    } finally {
      setLoading(false);
    }
  }

  async function verify(withName: boolean, e?: FormEvent) {
    e?.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: phone.replace(/\s/g, ""),
          code,
          ...(withName ? { name } : {}),
        }),
      });
      if (res.status === 428) {
        setStep("name");
        return;
      }
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Code incorrect.");
        return;
      }
      router.push(next.startsWith("/") ? next : "/dashboard");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-full max-w-md">
      <div className="animate-pop-in rounded-[2rem] border border-slate-200 bg-white p-8 shadow-card dark:border-white/10 dark:bg-night-800">
        <div className="mb-5 flex justify-center"><Logo size="lg" /></div>

        {step === "phone" && (
          <>
            <h1 className="text-center font-display text-2xl font-bold">Se connecter</h1>
            <p className="mt-1 text-center text-sm text-slate-500 dark:text-slate-400">
              Avec ton numéro de téléphone. Pas de mot de passe à retenir.
            </p>
            <form onSubmit={(e) => void requestCode(e)} className="mt-6 space-y-4">
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                inputMode="tel"
                autoComplete="tel"
                placeholder="+229 97 00 00 00"
                aria-label="Numéro de téléphone au format international"
                className={input}
                required
              />
              {error && <p role="alert" className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600 dark:bg-rose-400/10">{error}</p>}
              <button type="submit" disabled={loading || phone.trim().length < 8}
                className="btn-3d flex w-full items-center justify-center gap-2 rounded-2xl bg-night-900 py-4 font-display text-lg font-bold text-white shadow-deep disabled:opacity-50 dark:bg-nafa-500 dark:text-night-950">
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <MessageSquareLock className="h-5 w-5" />}
                Recevoir mon code
              </button>
            </form>
            <p className="mt-4 flex items-start gap-1.5 text-center text-[11px] font-semibold leading-relaxed text-slate-400">
              <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-nafa-500" />
              Démo : sans fournisseur SMS configuré, le code s'affiche à l'écran
              à l'étape suivante. En production, il arrive par SMS.
            </p>
          </>
        )}

        {step === "code" && (
          <>
            <h1 className="text-center font-display text-2xl font-bold">Vérifie ton numéro</h1>
            <p className="mt-1 text-center text-sm text-slate-500 dark:text-slate-400">
              Code envoyé au <strong>{phone}</strong>
            </p>
            {devCode && (
              <p className="mt-3 rounded-2xl bg-amber-50 p-3 text-center font-display text-lg font-bold tracking-[0.4em] text-amber-700 dark:bg-amber-400/10 dark:text-amber-300">
                {devCode}
              </p>
            )}
            <form onSubmit={(e) => void verify(false, e)} className="mt-5 space-y-4">
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="••••••"
                aria-label="Code à 6 chiffres"
                className={`${input} text-center tracking-[0.5em]`}
                required
              />
              {error && <p role="alert" className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600 dark:bg-rose-400/10">{error}</p>}
              <button type="submit" disabled={loading || code.length !== 6}
                className="btn-3d flex w-full items-center justify-center gap-2 rounded-2xl bg-night-900 py-4 font-display text-lg font-bold text-white shadow-deep disabled:opacity-50 dark:bg-nafa-500 dark:text-night-950">
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ArrowRight className="h-5 w-5" />}
                Valider
              </button>
              <button type="button" onClick={() => void requestCode()} disabled={loading}
                className="w-full text-sm font-bold text-slate-400 hover:text-nafa-600">
                Renvoyer un nouveau code
              </button>
            </form>
          </>
        )}

        {step === "name" && (
          <>
            <h1 className="text-center font-display text-2xl font-bold">Bienvenue !</h1>
            <p className="mt-1 text-center text-sm text-slate-500 dark:text-slate-400">
              C'est ta première visite : dis-moi ton nom et c'est réglé.
            </p>
            <form onSubmit={(e) => void verify(true, e)} className="mt-6 space-y-4">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
                placeholder="Prénom et nom"
                aria-label="Ton nom complet"
                className={input}
                minLength={2}
                required
              />
              {error && <p role="alert" className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600 dark:bg-rose-400/10">{error}</p>}
              <button type="submit" disabled={loading || name.trim().length < 2}
                className="btn-3d flex w-full items-center justify-center gap-2 rounded-2xl bg-night-900 py-4 font-display text-lg font-bold text-white shadow-deep disabled:opacity-50 dark:bg-nafa-500 dark:text-night-950">
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ArrowRight className="h-5 w-5" />}
                Créer mon compte NAFA
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
