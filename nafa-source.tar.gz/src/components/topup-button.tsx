"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Loader2, Plus } from "lucide-react";
import { cn } from "@/lib/cn";

export function TopupButton({ currency }: { currency: "NGN" | "XOF" }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function topup() {
    setLoading(true);
    try {
      await fetch("/api/topup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currency }),
      });
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      type="button"
      onClick={() => void topup()}
      disabled={loading}
      className={cn(
        "btn-3d inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-bold",
        currency === "NGN"
          ? "bg-white/15 text-white hover:bg-white/25"
          : "bg-night-900/10 text-night-800 hover:bg-night-900/20 dark:bg-white/10 dark:text-white dark:hover:bg-white/20",
      )}
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
      Recharger (démo)
    </button>
  );
}
