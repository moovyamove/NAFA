"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft, CheckCircle2, CircleDot, Copy, Loader2, RefreshCw, XCircle,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { Flag, StatusPill } from "./flags";
import { formatMinor, formatRate, type Currency } from "@/lib/money";

type Stage = { atSeconds: number; status: "pending" | "processing" | "success" | "failed"; label: string; detail: string };
type Tx = {
  trackingId: string;
  direction: "NGN_XOF" | "XOF_NGN";
  status: "pending" | "processing" | "success" | "failed";
  sendAmount: number;
  feeAmount: number;
  receiveAmount: number;
  rateApplied: number;
  rateKind: string;
  countryFrom: string;
  countryTo: string;
  beneficiaryName: string;
  beneficiaryAccount: string;
  method: { label: string; color: string; etaLabel: string; accountHint: string };
  createdAt: string;
  ageSeconds: number;
  stages: Stage[];
};

export function TxTracker({ trackingId }: { trackingId: string }) {
  const [tx, setTx] = useState<Tx | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    let stopped = false;
    async function pull() {
      try {
        const res = await fetch(`/api/transactions/${trackingId}`, { cache: "no-store" });
        if (stopped) return;
        if (!res.ok) {
          const data = (await res.json().catch(() => ({}))) as { error?: string };
          setError(data.error ?? "Suivi indisponible.");
          return;
        }
        const data = (await res.json()) as { transaction: Tx };
        setTx(data.transaction);
        if ((data.transaction.status === "success" || data.transaction.status === "failed") && timer.current) {
          clearInterval(timer.current);
        }
      } catch {
        if (!stopped) setError("Réseau indisponible — nouvelle tentative…");
      }
    }
    void pull();
    timer.current = setInterval(pull, 4000);
    return () => {
      stopped = true;
      if (timer.current) clearInterval(timer.current);
    };
  }, [trackingId]);

  if (error && !tx) {
    return (
      <div className="mx-auto max-w-md rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-card dark:border-white/10 dark:bg-night-800">
        <XCircle className="mx-auto h-10 w-10 text-rose-500" />
        <p className="mt-3 font-bold text-slate-600 dark:text-slate-300">{error}</p>
        <Link href="/dashboard" className="mt-4 inline-flex items-center gap-2 font-display font-bold text-nafa-600">
          <ArrowLeft className="h-4 w-4" /> Mon tableau de bord
        </Link>
      </div>
    );
  }

  if (!tx) {
    return (
      <div className="flex items-center justify-center gap-3 py-20 text-sm font-bold text-slate-400">
        <Loader2 className="h-5 w-5 animate-spin text-nafa-500" /> Chargement du suivi…
      </div>
    );
  }

  const source: Currency = tx.direction === "NGN_XOF" ? "NGN" : "XOF";
  const target: Currency = tx.direction === "NGN_XOF" ? "XOF" : "NGN";
  const final = tx.status === "success" || tx.status === "failed";
  const currentStageIndex = tx.status === "failed" ? -1 : tx.stages.findIndex((s) => s.status === tx.status);

  return (
    <div className="mx-auto max-w-xl space-y-4 animate-pop-in">
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-slate-400">Identifiant</p>
            <div className="mt-0.5 flex items-center gap-2">
              <h1 className="font-display text-2xl font-bold tracking-wider">{tx.trackingId}</h1>
              <button type="button" aria-label="Copier"
                onClick={() => { void navigator.clipboard.writeText(tx.trackingId); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
                className="btn-3d flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 dark:border-white/10 dark:bg-white/5">
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
            {copied && <p className="animate-pop-in text-xs font-bold text-nafa-600">Copié !</p>}
          </div>
          <StatusPill status={tx.status} />
        </div>

        {/* Timeline */}
        <ol className="mt-6 space-y-0">
          {(tx.status === "failed"
            ? [{ atSeconds: 0, status: "pending" as const, label: "En attente", detail: "Transfert créé" }, { atSeconds: 0, status: "failed" as const, label: "Échoué", detail: "Le transfert a été annulé. Contacte le support." }]
            : tx.stages
          ).map((stage, i) => {
            const done = currentStageIndex > i || tx.status === "success";
            const current = currentStageIndex === i;
            const failed = stage.status === "failed";
            return (
              <li key={stage.status + i} className="relative flex gap-4 pb-6 last:pb-0">
                {i < 2 && (
                  <span className={cn("absolute left-[13px] top-8 h-full w-0.5", done ? "bg-nafa-400" : "bg-slate-200 dark:bg-white/10")} />
                )}
                <span className={cn(
                  "z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
                  failed ? "bg-rose-100 text-rose-500 dark:bg-rose-400/15"
                    : done ? "bg-nafa-500 text-white"
                    : current ? "bg-sky-100 text-sky-600 dark:bg-sky-400/15"
                    : "bg-slate-100 text-slate-300 dark:bg-white/10",
                )}>
                  {failed ? <XCircle className="h-4 w-4" /> : done ? <CheckCircle2 className="h-4 w-4" /> : <CircleDot className={cn("h-4 w-4", current && "animate-pulse-soft")} />}
                </span>
                <div>
                  <p className={cn("font-display font-bold", current || done ? "text-slate-800 dark:text-slate-100" : "text-slate-400")}>{stage.label}</p>
                  <p className="text-xs font-semibold text-slate-400">{stage.detail}</p>
                </div>
                {current && !final && (
                  <span className="ml-auto inline-flex items-center gap-1 text-xs font-bold text-sky-500">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> en direct
                  </span>
                )}
              </li>
            );
          })}
        </ol>

        {!final && (
          <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-500 dark:bg-night-850 dark:text-slate-400">
            <RefreshCw className="h-3 w-3" /> Actualisation automatique toutes les 4 s · {tx.method.etaLabel}
          </p>
        )}
      </div>

      {/* Détails */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800">
        <h2 className="font-display text-lg font-bold">Détails du transfert</h2>
        <dl className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between"><dt className="font-semibold text-slate-500 dark:text-slate-400">Bénéficiaire</dt><dd className="font-bold">{tx.beneficiaryName}</dd></div>
          <div className="flex justify-between"><dt className="font-semibold text-slate-500 dark:text-slate-400">Réception</dt>
            <dd className="font-bold" style={{ color: tx.method.color }}>{tx.method.label} · {tx.beneficiaryAccount}</dd></div>
          <div className="flex justify-between"><dt className="font-semibold text-slate-500 dark:text-slate-400">Itinéraire</dt>
            <dd className="flex items-center gap-1.5 font-bold">{tx.countryFrom}<Flag code={tx.direction === "NGN_XOF" ? "NG" : "BJ"} className="h-3.5 w-5" /> → {tx.countryTo}<Flag code={tx.direction === "NGN_XOF" ? "BJ" : "NG"} className="h-3.5 w-5" /></dd></div>
          <div className="flex justify-between"><dt className="font-semibold text-slate-500 dark:text-slate-400">Envoyé</dt><dd className="font-bold tabular-nums">{formatMinor(tx.sendAmount, source)}</dd></div>
          <div className="flex justify-between"><dt className="font-semibold text-slate-500 dark:text-slate-400">Frais</dt><dd className="font-bold tabular-nums text-rose-500">− {formatMinor(tx.feeAmount, source)}</dd></div>
          <div className="flex justify-between"><dt className="font-semibold text-slate-500 dark:text-slate-400">Taux ({tx.rateKind === "official" ? "officiel" : "parallèle"})</dt>
            <dd className="font-bold tabular-nums">{tx.direction === "NGN_XOF" ? `1 ₦ = ${formatRate(tx.rateApplied, "NGN_XOF")} F` : `1 F = ${formatRate(tx.rateApplied, "XOF_NGN")} ₦`}</dd></div>
          <div className="flex justify-between border-t border-dashed border-slate-200 pt-2 dark:border-white/10">
            <dt className="font-semibold text-slate-500 dark:text-slate-400">Reçu par le bénéficiaire</dt>
            <dd className="font-display text-base font-bold tabular-nums text-nafa-600 dark:text-nafa-300">{formatMinor(tx.receiveAmount, target)}</dd>
          </div>
        </dl>
      </div>

      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-nafa-600">
        <ArrowLeft className="h-4 w-4" /> Retour au tableau de bord
      </Link>
    </div>
  );
}
