"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { LogOut } from "lucide-react";

export function LogoutButton() {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <button
      type="button"
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          await fetch("/api/auth/logout", { method: "POST" });
          router.push("/");
          router.refresh();
        })
      }
      className="btn-3d inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold text-slate-400 transition hover:bg-white/10 hover:text-white"
    >
      <LogOut className="h-4 w-4" />
      Déconnexion
    </button>
  );
}
