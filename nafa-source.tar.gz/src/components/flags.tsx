/** Drapeaux SVG inline — Nigeria + 8 pays UEMOA. Léger, net à toute taille. */
import type { ReactNode } from "react";
import { ArrowLeftRight, ShieldCheck } from "lucide-react";
import Image from "next/image";

export const UEMOA = [
  { code: "BJ", name: "Bénin" },
  { code: "TG", name: "Togo" },
  { code: "CI", name: "Côte d'Ivoire" },
  { code: "SN", name: "Sénégal" },
  { code: "BF", name: "Burkina Faso" },
  { code: "ML", name: "Mali" },
  { code: "NE", name: "Niger" },
  { code: "GW", name: "Guinée-Bissau" },
] as const;

export const NIGERIA = { code: "NG", name: "Nigeria" } as const;
export type CountryCode = "NG" | (typeof UEMOA)[number]["code"];

export function Flag({ code, className = "h-5 w-7" }: { code: string; className?: string }) {
  const wrap = (children: ReactNode) => (
    <svg viewBox="0 0 28 20" className={`${className} shrink-0 rounded-[3px] shadow-sm`} aria-hidden>
      {children}
    </svg>
  );
  switch (code) {
    case "NG":
      return wrap(<><rect width="9.33" height="20" fill="#008751" /><rect x="9.33" width="9.34" height="20" fill="#ffffff" /><rect x="18.67" width="9.33" height="20" fill="#008751" /></>);
    case "BJ":
      return wrap(<><rect width="28" height="10" x="11" fill="#FCD116" /><rect y="10" x="11" width="17" height="10" fill="#E8112D" /><rect width="11" height="20" fill="#008751" /></>);
    case "TG":
      return wrap(<><rect width="28" height="20" fill="#006A4E" /><rect y="4" width="28" height="4" fill="#FFCE00" /><rect y="12" width="28" height="4" fill="#FFCE00" /><rect width="11" height="11" fill="#D21034" /><polygon points="5.5,2 6.4,4.6 9.2,4.6 6.9,6.4 7.8,9 5.5,7.2 3.2,9 4.1,6.4 1.8,4.6 4.6,4.6" fill="#fff" /></>);
    case "CI":
      return wrap(<><rect width="9.33" height="20" fill="#F77F00" /><rect x="9.33" width="9.34" height="20" fill="#fff" /><rect x="18.67" width="9.33" height="20" fill="#009E60" /></>);
    case "SN":
      return wrap(<><rect width="9.33" height="20" fill="#00853F" /><rect x="9.33" width="9.34" height="20" fill="#FDEF42" /><rect x="18.67" width="9.33" height="20" fill="#E31B23" /><polygon points="14,7 14.7,9.2 17,9.2 15.1,10.5 15.8,12.8 14,11.4 12.2,12.8 12.9,10.5 11,9.2 13.3,9.2" fill="#00853F" /></>);
    case "BF":
      return wrap(<><rect width="28" height="10" fill="#EF2B2D" /><rect y="10" width="28" height="10" fill="#009E49" /><polygon points="14,5.6 14.9,8.5 17.9,8.5 15.5,10.3 16.4,13.2 14,11.4 11.6,13.2 12.5,10.3 10.1,8.5 13.1,8.5" fill="#FCD116" /></>);
    case "ML":
      return wrap(<><rect width="9.33" height="20" fill="#14B53A" /><rect x="9.33" width="9.34" height="20" fill="#FCD116" /><rect x="18.67" width="9.33" height="20" fill="#CE1126" /></>);
    case "NE":
      return wrap(<><rect width="28" height="7" fill="#E05206" /><rect y="7" width="28" height="7" fill="#fff" /><rect y="14" width="28" height="6" fill="#0DB02B" /><circle cx="14" cy="10.5" r="2.4" fill="#E05206" /></>);
    case "GW":
      return wrap(<><rect width="28" height="10" x="10" fill="#FCD116" /><rect y="10" x="10" width="18" height="10" fill="#009E49" /><rect width="10" height="20" fill="#CE1126" /><polygon points="5,6.5 5.7,8.7 8,8.7 6.2,10.1 6.9,12.4 5,11 3.1,12.4 3.8,10.1 2,8.7 4.3,8.7" fill="#000" /></>);
    default:
      return null;
  }
}

/* ---------------------------------- logo ----------------------------------- */

export function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const dims = { sm: 28, md: 36, lg: 52 }[size];
  return (
    <span className="inline-flex items-center gap-2.5 select-none">
      <Image src="/images/logo.png" alt="Logo NAFA" width={dims} height={dims} className="rounded-xl shadow-card" priority />
      <span className={`font-display font-bold tracking-tight ${size === "lg" ? "text-3xl" : size === "md" ? "text-xl" : "text-lg"}`}>
        NAFA
      </span>
    </span>
  );
}

/* ------------------------------ petits utilitaires -------------------------- */

export function TrustBadge({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
      <ShieldCheck className="h-3.5 w-3.5 text-nafa-500" />
      {children}
    </span>
  );
}

export function DirectionChip({ direction }: { direction: "NGN_XOF" | "XOF_NGN" }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-bold text-slate-500 dark:bg-white/10 dark:text-slate-300">
      {direction === "NGN_XOF" ? "NGN → XOF" : "XOF → NGN"}
      <ArrowLeftRight className="h-3 w-3" />
    </span>
  );
}

export function StatusPill({ status }: { status: "pending" | "processing" | "success" | "failed" }) {
  const map = {
    pending: { label: "En attente", cls: "bg-amber-100 text-amber-700 dark:bg-amber-400/15 dark:text-amber-300" },
    processing: { label: "En cours", cls: "bg-sky-100 text-sky-700 dark:bg-sky-400/15 dark:text-sky-300" },
    success: { label: "Réussi", cls: "bg-nafa-100 text-nafa-700 dark:bg-nafa-400/15 dark:text-nafa-300" },
    failed: { label: "Échoué", cls: "bg-rose-100 text-rose-700 dark:bg-rose-400/15 dark:text-rose-300" },
  }[status];
  return <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-bold ${map.cls}`}>{map.label}</span>;
}
