"use client";

import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowDownUp, ChevronRight, Loader2, Send, TrendingUp, Zap,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { Flag, NIGERIA, UEMOA } from "./flags";
import {
  CURRENCY_META,
  computeQuote,
  directionMeta,
  formatMinor,
  formatRate,
  majorToMinor,
  type Direction,
  type RateKind,
} from "@/lib/money";

/* Types locaux reflétant GET /api/rates */
type ApiRate = {
  kind: RateKind;
  source: string;
  updatedAt: string;
  marginPercent: number;
  base: Record<Direction, number>;
  applied: Record<Direction, number>;
};
type ApiMethod = {
  id: string;
  zone: "NG" | "XOF";
  code: string;
  label: string;
  type: "mobile_money" | "bank" | "fintech";
  feePercent: string;
  feeFixedNgn: number;
  feeFixedXof: number;
  etaLabel: string;
  color: string;
  accountHint: string;
};

const QUICK_AMOUNTS_NGN = ["10000", "50000", "100000", "500000"];
const QUICK_AMOUNTS_XOF = ["25000", "50000", "100000", "500000"];

export function Converter({ user }: { user: { name: string } | null }) {
  const router = useRouter();
  const [data, setData] = useState<{ rates: ApiRate[]; methods: ApiMethod[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [direction, setDirection] = useState<Direction>("NGN_XOF");
  const [rateKind, setRateKind] = useState<RateKind>("parallel");
  const [amount, setAmount] = useState("50000");
  const [uemoa, setUemoa] = useState<string>("BJ");
  const [methodId, setMethodId] = useState<string>("");

  useEffect(() => {
    fetch("/api/rates", { cache: "no-store" })
      .then((r) => r.json())
      .then((d: { rates: ApiRate[]; methods: ApiMethod[] }) => setData(d))
      .catch(() => setError("Impossible de charger les taux. Réessaie."));
  }, []);

  const { source, target } = directionMeta(direction);
  const methods = useMemo(
    () => (data?.methods ?? []).filter((m) => m.zone === target),
    [data, target],
  );
  const method = methods.find((m) => m.id === methodId) ?? methods[0];

  useEffect(() => {
    if (methods.length > 0 && !methods.some((m) => m.id === methodId)) {
      setMethodId(methods[0].id);
    }
  }, [methods, methodId]);

  const rate = data?.rates.find((r) => r.kind === rateKind);
  const official = data?.rates.find((r) => r.kind === "official");
  const parallel = data?.rates.find((r) => r.kind === "parallel");

  const quote = useMemo(() => {
    if (!rate || !method) return null;
    const sendMinor = majorToMinor(Number(amount.replace(/\s/g, "").replace(",", ".")), source);
    // Forme compatible avec computeQuote (types drizzle inférés acceptant string)
    const methodLike = {
      ...method,
      feePercent: Number(method.feePercent),
    } as unknown as Parameters<typeof computeQuote>[0]["method"];
    const rateLike = {
      ngnToXof: rate.base.NGN_XOF,
      xofToNgn: rate.base.XOF_NGN,
      marginPercent: rate.marginPercent,
    } as unknown as Parameters<typeof computeQuote>[0]["rate"];
    return computeQuote({ direction, rateKind, sendMinor, rate: rateLike, method: methodLike });
  }, [rate, method, amount, source, direction, rateKind]);

  function swap() {
    setDirection((d) => (d === "NGN_XOF" ? "XOF_NGN" : "NGN_XOF"));
  }

  const sourceCountry = direction === "NGN_XOF" ? NIGERIA : UEMOA.find((c) => c.code === uemoa)!;
  const targetCountry = direction === "NGN_XOF" ? UEMOA.find((c) => c.code === uemoa)! : NIGERIA;
  const quick = source === "NGN" ? QUICK_AMOUNTS_NGN : QUICK_AMOUNTS_XOF;

  function goSend() {
    if (!quote || !method) return;
    const params = new URLSearchParams({
      dir: direction,
      kind: rateKind,
      method: method.id,
      amount: amount.replace(/\s/g, "").replace(",", "."),
      cf: sourceCountry.name,
      ct: targetCountry.name,
    });
    router.push(user ? `/send?${params}` : `/login?next=/send?${params}`);
  }

  const card = "rounded-3xl border border-slate-200/80 bg-white shadow-card dark:border-white/10 dark:bg-night-800";

  return (
    <div className={`${card} animate-pop-in p-5 sm:p-6`}>
      {!data && !error && (
        <div className="flex items-center justify-center gap-3 py-16 text-sm font-bold text-slate-400">
          <Loader2 className="h-5 w-5 animate-spin text-nafa-500" /> Chargement des taux en direct…
        </div>
      )}
      {error && (
        <p role="alert" className="rounded-2xl bg-rose-50 p-4 text-sm font-bold text-rose-600 dark:bg-rose-400/10">{error}</p>
      )}

      {data && rate && quote && method && (
        <>
          {/* Sélecteur de taux */}
          <div className="grid grid-cols-2 gap-2">
            {([
              ["official", "Taux officiel", official],
              ["parallel", "Marché parallèle", parallel],
            ] as const).map(([kind, label, r]) => (
              <button
                key={kind}
                type="button"
                onClick={() => setRateKind(kind)}
                aria-pressed={rateKind === kind}
                className={cn(
                  "btn-3d rounded-2xl border-2 p-3 text-left transition",
                  rateKind === kind
                    ? "border-nafa-500 bg-nafa-50 dark:border-nafa-400 dark:bg-nafa-400/10"
                    : "border-slate-200 bg-white hover:border-slate-300 dark:border-white/10 dark:bg-night-850",
                )}
              >
                <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-400">
                  {kind === "parallel" ? <TrendingUp className="h-3 w-3" /> : <Zap className="h-3 w-3" />}
                  {label}
                </span>
                <span className={cn("mt-0.5 block font-display text-lg font-bold tabular-nums", rateKind === kind ? "text-nafa-700 dark:text-nafa-300" : "text-slate-600 dark:text-slate-300")}>
                  {r ? `1 ₦ = ${formatRate(r.applied.NGN_XOF, "NGN_XOF")} F` : "—"}
                </span>
              </button>
            ))}
          </div>
          <p className="mt-2 text-[11px] font-semibold text-slate-400">
            {rateKind === "parallel"
              ? "Marché intermédiaire : cours généralement plus avantageux, ajusté chaque jour."
              : "Cours officiel fourni par la banque centrale / agrégateurs de change."}
          </p>

          {/* Montants */}
          <div className="mt-5 space-y-3">
            <div className="rounded-2xl border-2 border-slate-200 bg-slate-50/60 p-4 dark:border-white/10 dark:bg-night-850">
              <div className="flex items-center justify-between">
                <label htmlFor="amount" className="text-xs font-bold uppercase tracking-wide text-slate-400">
                  Tu envoies · {sourceCountry.name}
                </label>
                <span className="flex items-center gap-1.5 text-sm font-bold text-slate-600 dark:text-slate-300">
                  <Flag code={sourceCountry.code} className="h-4 w-6" /> {source}
                </span>
              </div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="font-display text-2xl font-bold text-slate-400">{CURRENCY_META[source].symbol}</span>
                <input
                  id="amount"
                  inputMode="decimal"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value.replace(/[^\d.,]/g, ""))}
                  className="amount-input w-full bg-transparent font-display text-4xl font-bold text-slate-900 focus:outline-none dark:text-white"
                  aria-label={`Montant à envoyer en ${source}`}
                />
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {quick.map((q) => (
                  <button key={q} type="button" onClick={() => setAmount(q)}
                    className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-500 transition hover:border-nafa-400 hover:text-nafa-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                    {new Intl.NumberFormat("fr-FR").format(Number(q))}
                  </button>
                ))}
              </div>
            </div>

            {/* Swap */}
            <div className="relative z-10 -my-5 flex justify-center">
              <button type="button" onClick={swap} aria-label="Inverser la direction"
                className="btn-3d flex h-11 w-11 items-center justify-center rounded-full border-4 border-white bg-nafa-500 text-white shadow-deep transition hover:bg-nafa-600 dark:border-night-900">
                <ArrowDownUp className="h-5 w-5" />
              </button>
            </div>

            <div className="rounded-2xl border-2 border-nafa-200 bg-nafa-50/70 p-4 dark:border-nafa-400/30 dark:bg-nafa-400/5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wide text-nafa-700/70 dark:text-nafa-300/70">
                  Le bénéficiaire reçoit · {targetCountry.name}
                </span>
                <span className="flex items-center gap-1.5 text-sm font-bold text-nafa-700 dark:text-nafa-300">
                  <Flag code={targetCountry.code} className="h-4 w-6" /> {target}
                </span>
              </div>
              <div className="mt-1 font-display text-4xl font-bold tabular-nums text-nafa-700 dark:text-nafa-300">
                {formatMinor(quote.receiveAmount, target)}
              </div>
            </div>
          </div>

          {/* Pays UEMOA */}
          <div>
            <label htmlFor="uemoa" className="mb-1.5 mt-4 block text-xs font-bold uppercase tracking-wide text-slate-400">
              {direction === "NGN_XOF" ? "Pays de destination (UEMOA)" : "Pays d'origine (UEMOA)"}
            </label>
            <div className="relative">
              <select
                id="uemoa"
                value={uemoa}
                onChange={(e) => setUemoa(e.target.value)}
                className="w-full appearance-none rounded-2xl border-2 border-slate-200 bg-white py-3 pl-12 pr-4 font-bold text-slate-800 focus:border-nafa-400 focus:outline-none dark:border-white/10 dark:bg-night-850 dark:text-slate-100"
              >
                {UEMOA.map((c) => (
                  <option key={c.code} value={c.code}>{c.name}</option>
                ))}
              </select>
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2">
                <Flag code={uemoa} className="h-4 w-6" />
              </span>
            </div>
          </div>

          {/* Méthode de réception */}
          <div className="mt-4">
            <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-400">
              Réception via
            </span>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {methods.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMethodId(m.id)}
                  aria-pressed={method.id === m.id}
                  className={cn(
                    "btn-3d rounded-2xl border-2 p-3 text-left transition",
                    method.id === m.id
                      ? "border-night-900 bg-night-900 text-white dark:border-white dark:bg-white dark:text-night-900"
                      : "border-slate-200 bg-white hover:border-slate-300 dark:border-white/10 dark:bg-night-850",
                  )}
                >
                  <span className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg text-[10px] font-black text-white" style={{ background: m.color }}>
                      {m.label.slice(0, 2).toUpperCase()}
                    </span>
                    <span className="truncate text-sm font-bold">{m.label}</span>
                  </span>
                  <span className={cn("mt-1 block text-[11px] font-semibold", method.id === m.id ? "text-white/70 dark:text-night-700" : "text-slate-400")}>
                    {m.etaLabel}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Détail transparent */}
          <dl className="mt-5 space-y-2 rounded-2xl bg-slate-50 p-4 text-sm dark:bg-night-850">
            <div className="flex justify-between">
              <dt className="font-semibold text-slate-500 dark:text-slate-400">Taux appliqué (marge incluse)</dt>
              <dd className="font-bold tabular-nums text-slate-800 dark:text-slate-100">
                {direction === "NGN_XOF"
                  ? `1 ₦ = ${formatRate(quote.rate, "NGN_XOF")} F`
                  : `1 F = ${formatRate(quote.rate, "XOF_NGN")} ₦`}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="font-semibold text-slate-500 dark:text-slate-400">
                Frais NAFA ({quote.feePercent}%{quote.feeFixed > 0 ? ` + ${formatMinor(quote.feeFixed, source)}` : ""})
              </dt>
              <dd className="font-bold tabular-nums text-rose-500">− {formatMinor(quote.feeAmount, source)}</dd>
            </div>
            <div className="flex justify-between border-t border-dashed border-slate-200 pt-2 dark:border-white/10">
              <dt className="font-semibold text-slate-500 dark:text-slate-400">Montant converti</dt>
              <dd className="font-bold tabular-nums text-slate-800 dark:text-slate-100">{formatMinor(quote.netAmount, source)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="font-semibold text-slate-500 dark:text-slate-400">Le bénéficiaire reçoit</dt>
              <dd className="font-display text-base font-bold tabular-nums text-nafa-600 dark:text-nafa-300">
                {formatMinor(quote.receiveAmount, target)}
              </dd>
            </div>
          </dl>

          <button
            type="button"
            onClick={goSend}
            className="btn-3d mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-night-900 py-4 font-display text-lg font-bold text-white shadow-deep transition hover:bg-night-800 dark:bg-nafa-500 dark:text-night-950 dark:hover:bg-nafa-400"
          >
            <Send className="h-5 w-5" />
            Envoyer {formatMinor(quote.netAmount, source)}
            <ChevronRight className="h-5 w-5" />
          </button>
          <p className="mt-2 text-center text-[11px] font-semibold text-slate-400">
            {user ? `Connecté : ${user.name}` : "Création de compte en 30 secondes au moment de l'envoi — la simulation reste libre."}
          </p>
        </>
      )}
    </div>
  );
}
