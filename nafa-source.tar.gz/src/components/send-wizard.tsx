"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft, ArrowRight, Check, CheckCircle2, Copy, Loader2, PartyPopper, ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { Flag, StatusPill } from "./flags";
import { NIGERIA, UEMOA } from "./flags";
import {
  computeQuote,
  directionMeta,
  formatMinor,
  formatRate,
  majorToMinor,
  type Direction,
  type RateKind,
} from "@/lib/money";

type ApiRate = { kind: RateKind; base: Record<Direction, number>; marginPercent: number };
type ApiMethod = {
  id: string; zone: "NG" | "XOF"; label: string; type: string;
  feePercent: string; feeFixedNgn: number; feeFixedXof: number;
  etaLabel: string; color: string; accountHint: string;
};

const STEPS = ["Montant", "Bénéficiaire", "Récapitulatif", "Envoyé"];

export function SendWizard() {
  const router = useRouter();
  const params = useSearchParams();
  const [step, setStep] = useState(0);
  const [data, setData] = useState<{ rates: ApiRate[]; methods: ApiMethod[] } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [trackingId, setTrackingId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const direction = (params.get("dir") === "XOF_NGN" ? "XOF_NGN" : "NGN_XOF") as Direction;
  const rateKind = (params.get("kind") === "official" ? "official" : "parallel") as RateKind;
  const amountStr = params.get("amount") ?? "50000";
  const paramMethod = params.get("method") ?? "";
  const cf = params.get("cf") ?? "";
  const ct = params.get("ct") ?? "";

  const [beneficiaryName, setBeneficiaryName] = useState("");
  const [account, setAccount] = useState("");

  useEffect(() => {
    fetch("/api/rates", { cache: "no-store" })
      .then((r) => r.json())
      .then((d: { rates: ApiRate[]; methods: ApiMethod[] }) => setData(d))
      .catch(() => setError("Impossible de charger les taux."));
  }, []);

  const { source, target } = directionMeta(direction);
  const method = useMemo(
    () => (data?.methods ?? []).find((m) => m.id === paramMethod) ?? (data?.methods ?? []).filter((m) => m.zone === target)[0],
    [data, paramMethod, target],
  );
  const rate = data?.rates.find((r) => r.kind === rateKind);

  const quote = useMemo(() => {
    if (!rate || !method) return null;
    const sendMinor = majorToMinor(Number(amountStr), source);
    return computeQuote({
      direction,
      rateKind,
      sendMinor,
      rate: rate as unknown as Parameters<typeof computeQuote>[0]["rate"],
      method: { ...method, feePercent: Number(method.feePercent) } as unknown as Parameters<typeof computeQuote>[0]["method"],
    });
  }, [rate, method, amountStr, source, direction, rateKind]);

  const countryFrom = direction === "NGN_XOF" ? NIGERIA : UEMOA.find((c) => c.name === cf) ?? UEMOA[0];
  const countryTo = direction === "NGN_XOF" ? UEMOA.find((c) => c.name === ct) ?? UEMOA[0] : NIGERIA;
  const cfName = cf || countryFrom.name;
  const ctName = ct || countryTo.name;

  function accountValid(): boolean {
    const clean = account.replace(/[\s-]/g, "");
    if (!method) return false;
    if (method.type === "mobile_money" || method.type === "fintech") return /^\d{8,15}$/.test(clean);
    if (method.id.includes("bank-ng")) return /^\d{10}$/.test(clean);
    return /^[0-9A-Z]{10,34}$/i.test(clean);
  }

  async function confirm() {
    if (!quote || !method) return;
    setSending(true);
    setError(null);
    try {
      const res = await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          direction,
          rateKind,
          methodId: method.id,
          sendAmount: quote.netAmount / 100 + quote.feeAmount / 100,
          countryFrom: cfName,
          countryTo: ctName,
          beneficiaryName: beneficiaryName.trim(),
          beneficiaryAccount: account.replace(/\s/g, ""),
        }),
      });
      const data = (await res.json()) as { error?: string; trackingId?: string };
      if (!res.ok || !data.trackingId) {
        setError(data.error ?? "Envoi impossible pour le moment.");
        return;
      }
      setTrackingId(data.trackingId);
      setStep(3);
    } finally {
      setSending(false);
    }
  }

  const card = "rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800";

  return (
    <div className="mx-auto w-full max-w-xl">
      {/* Étapes */}
      <ol className="mb-5 flex items-center gap-1" aria-label="Étapes de l'envoi">
        {STEPS.map((label, i) => (
          <li key={label} className="flex flex-1 flex-col items-center gap-1">
            <span className={cn(
              "flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition",
              i < step ? "bg-nafa-500 text-white" : i === step ? "bg-night-900 text-white dark:bg-white dark:text-night-900" : "bg-slate-200 text-slate-400 dark:bg-white/10",
            )}>
              {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
            </span>
            <span className={cn("text-[10px] font-bold", i === step ? "text-slate-700 dark:text-slate-200" : "text-slate-400")}>{label}</span>
          </li>
        ))}
      </ol>

      {error && (
        <p role="alert" className="mb-4 animate-pop-in rounded-2xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600 dark:bg-rose-400/10">{error}</p>
      )}

      {/* Étape 1 — montant */}
      {step === 0 && quote && method && (
        <section className={`${card} animate-pop-in`}>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold">Ton transfert</h2>
            <span className="flex items-center gap-2 text-sm font-bold text-slate-500">
              <Flag code={countryFrom.code} className="h-4 w-6" />
              <ArrowRight className="h-3.5 w-3.5" />
              <Flag code={countryTo.code} className="h-4 w-6" />
            </span>
          </div>
          <dl className="mt-4 space-y-2 text-sm">
            <Row k="J'envoie (avec frais)" v={formatMinor(quote.sendAmount, source)} bold />
            <Row k="Taux appliqué" v={direction === "NGN_XOF" ? `1 ₦ = ${formatRate(quote.rate, "NGN_XOF")} F` : `1 F = ${formatRate(quote.rate, "XOF_NGN")} ₦`} />
            <Row k={`Type de taux`} v={rateKind === "official" ? "Officiel" : "Marché parallèle"} />
            <Row k="Frais NAFA" v={`− ${formatMinor(quote.feeAmount, source)}`} danger />
            <Row k="Montant converti" v={formatMinor(quote.netAmount, source)} />
            <Row k={`Réception via ${method.label}`} v={method.etaLabel} />
            <Row k="Le bénéficiaire reçoit" v={formatMinor(quote.receiveAmount, target)} accent />
          </dl>
          <div className="mt-5 flex gap-3">
            <Link href="/" className="btn-3d flex flex-1 items-center justify-center gap-1.5 rounded-2xl border-2 border-slate-200 py-3.5 font-display font-bold text-slate-500 dark:border-white/10 dark:text-slate-300">
              <ArrowLeft className="h-4 w-4" /> Modifier
            </Link>
            <button type="button" onClick={() => setStep(1)}
              className="btn-3d flex flex-[2] items-center justify-center gap-2 rounded-2xl bg-night-900 py-3.5 font-display font-bold text-white shadow-deep dark:bg-nafa-500 dark:text-night-950">
              Continuer <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </section>
      )}

      {/* Étape 2 — bénéficiaire */}
      {step === 1 && method && (
        <section className={`${card} animate-pop-in`}>
          <h2 className="font-display text-xl font-bold">Qui reçoit l'argent ?</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Réception via <strong style={{ color: method.color }}>{method.label}</strong> — {method.accountHint}
          </p>
          <div className="mt-5 space-y-4">
            <div>
              <label htmlFor="bn" className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-400">Nom complet du bénéficiaire</label>
              <input id="bn" value={beneficiaryName} onChange={(e) => setBeneficiaryName(e.target.value)}
                placeholder="Ex. Kofi Mensah" autoComplete="off"
                className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50/60 px-4 py-3.5 font-bold focus:border-nafa-400 focus:bg-white focus:outline-none dark:border-white/10 dark:bg-night-850 dark:focus:bg-night-850" />
            </div>
            <div>
              <label htmlFor="acct" className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-400">
                {method.type === "bank" ? "RIB / IBAN / N° de compte" : "Numéro mobile money"}
              </label>
              <input id="acct" value={account} onChange={(e) => setAccount(e.target.value)}
                placeholder={method.accountHint} inputMode="numeric" autoComplete="off"
                className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50/60 px-4 py-3.5 font-display font-bold tracking-wider focus:border-nafa-400 focus:bg-white focus:outline-none dark:border-white/10 dark:bg-night-850 dark:focus:bg-night-850" />
              {account.length > 3 && !accountValid() && (
                <p className="mt-1.5 text-xs font-bold text-amber-600">Format attendu : {method.accountHint}</p>
              )}
            </div>
          </div>
          <div className="mt-5 flex gap-3">
            <button type="button" onClick={() => setStep(0)}
              className="btn-3d flex flex-1 items-center justify-center gap-1.5 rounded-2xl border-2 border-slate-200 py-3.5 font-display font-bold text-slate-500 dark:border-white/10 dark:text-slate-300">
              <ArrowLeft className="h-4 w-4" /> Retour
            </button>
            <button type="button" onClick={() => setStep(2)} disabled={beneficiaryName.trim().length < 2 || !accountValid()}
              className="btn-3d flex flex-[2] items-center justify-center gap-2 rounded-2xl bg-night-900 py-3.5 font-display font-bold text-white shadow-deep disabled:opacity-50 dark:bg-nafa-500 dark:text-night-950">
              Vérifier <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </section>
      )}

      {/* Étape 3 — récapitulatif */}
      {step === 2 && quote && method && (
        <section className={`${card} animate-pop-in`}>
          <h2 className="font-display text-xl font-bold">Récapitulatif</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <Row k="Bénéficiaire" v={beneficiaryName} bold />
            <Row k="Coordonnées" v={`${method.label} · ${account}`} />
            <Row k="Itinéraire" v={`${cfName} → ${ctName}`} />
            <Row k="Tu envoies" v={formatMinor(quote.sendAmount, source)} bold />
            <Row k="Frais" v={`− ${formatMinor(quote.feeAmount, source)}`} danger />
            <Row k="Taux" v={direction === "NGN_XOF" ? `1 ₦ = ${formatRate(quote.rate, "NGN_XOF")} F` : `1 F = ${formatRate(quote.rate, "XOF_NGN")} ₦`} />
            <Row k="Le bénéficiaire reçoit" v={formatMinor(quote.receiveAmount, target)} accent />
          </dl>
          <p className="mt-4 flex items-start gap-2 rounded-2xl bg-slate-50 p-3 text-xs font-semibold leading-relaxed text-slate-500 dark:bg-night-850 dark:text-slate-400">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-nafa-500" />
            En confirmant, le montant « j'envoie » est débité de ton portefeuille NAFA.
            Démo : aucun argent réel ne circule.
          </p>
          <div className="mt-5 flex gap-3">
            <button type="button" onClick={() => setStep(1)} disabled={sending}
              className="btn-3d flex flex-1 items-center justify-center gap-1.5 rounded-2xl border-2 border-slate-200 py-3.5 font-display font-bold text-slate-500 dark:border-white/10 dark:text-slate-300">
              <ArrowLeft className="h-4 w-4" /> Retour
            </button>
            <button type="button" onClick={() => void confirm()} disabled={sending}
              className="btn-3d flex flex-[2] items-center justify-center gap-2 rounded-2xl bg-nafa-500 py-3.5 font-display text-lg font-bold text-night-950 shadow-deep disabled:opacity-60">
              {sending ? <Loader2 className="h-5 w-5 animate-spin" /> : <CheckCircle2 className="h-5 w-5" />}
              Confirmer l'envoi
            </button>
          </div>
        </section>
      )}

      {/* Étape 4 — succès + suivi */}
      {step === 3 && trackingId && quote && (
        <section className={`${card} animate-pop-in text-center`}>
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-nafa-100 dark:bg-nafa-400/15">
            <PartyPopper className="h-8 w-8 text-nafa-600 dark:text-nafa-300" />
          </span>
          <h2 className="mt-4 font-display text-2xl font-bold">Transfert créé !</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Le bénéficiaire recevra {formatMinor(quote.receiveAmount, target)} via {method?.label}.
          </p>
          <div className="mt-4 flex items-center justify-center gap-2">
            <span className="rounded-xl bg-slate-100 px-4 py-2 font-display text-lg font-bold tracking-widest dark:bg-night-850">{trackingId}</span>
            <button type="button" aria-label="Copier l'identifiant"
              onClick={() => { void navigator.clipboard.writeText(trackingId); setCopied(true); setTimeout(() => setCopied(false), 1600); }}
              className="btn-3d flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 dark:border-white/10 dark:bg-white/5">
              <Copy className="h-4 w-4" />
            </button>
          </div>
          {copied && <p className="animate-pop-in mt-1.5 text-xs font-bold text-nafa-600">Copié !</p>}
          <div className="mt-2"><StatusPill status="pending" /></div>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <Link href={`/tx/${trackingId}`}
              className="btn-3d flex items-center justify-center rounded-2xl bg-night-900 py-3.5 font-display font-bold text-white dark:bg-white dark:text-night-900">
              Suivre en direct
            </Link>
            <Link href="/dashboard"
              className="btn-3d flex items-center justify-center rounded-2xl border-2 border-slate-200 py-3.5 font-display font-bold text-slate-600 dark:border-white/10 dark:text-slate-300">
              Tableau de bord
            </Link>
          </div>
        </section>
      )}

      {(!data || !quote) && !error && (
        <div className={`${card} flex items-center justify-center gap-3 py-16 text-sm font-bold text-slate-400`}>
          <Loader2 className="h-5 w-5 animate-spin text-nafa-500" /> Préparation du transfert…
        </div>
      )}
    </div>
  );
}

function Row({ k, v, bold, accent, danger }: { k: string; v: string; bold?: boolean; accent?: boolean; danger?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-dashed border-slate-200 pb-2 last:border-0 last:pb-0 dark:border-white/10">
      <dt className="font-semibold text-slate-500 dark:text-slate-400">{k}</dt>
      <dd className={cn(
        "text-right tabular-nums",
        accent ? "font-display text-base font-bold text-nafa-600 dark:text-nafa-300"
          : danger ? "font-bold text-rose-500"
          : bold ? "font-bold text-slate-800 dark:text-slate-100"
          : "font-semibold text-slate-600 dark:text-slate-300",
      )}>{v}</dd>
    </div>
  );
}
