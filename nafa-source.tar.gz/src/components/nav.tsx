"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import {
  Bell, Home, LayoutDashboard, LineChart, LogOut, ShieldCheck, UserRound,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { Logo } from "./flags";
import { ThemeToggle } from "./theme-toggle";

type Props = {
  user: { name: string; role: "USER" | "ADMIN" } | null;
  unread: number;
};

const LINKS = [
  { href: "/", label: "Convertir", icon: Home },
  { href: "/dashboard", label: "Tableau", icon: LayoutDashboard },
  { href: "/rates", label: "Taux", icon: LineChart },
  { href: "/alerts", label: "Alertes", icon: Bell },
];

export function Nav({ user, unread }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState(false);

  function logout() {
    startTransition(async () => {
      try {
        await fetch("/api/auth/logout", { method: "POST" });
        router.push("/");
        router.refresh();
      } catch {
        setError(true);
      }
    });
  }

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const linkCls = (href: string) =>
    cn(
      "inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition",
      isActive(href)
        ? "bg-night-900 text-white dark:bg-white dark:text-night-900"
        : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-300 dark:hover:bg-white/10 dark:hover:text-white",
    );

  return (
    <>
      {/* Barre supérieure */}
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/85 backdrop-blur-lg dark:border-white/10 dark:bg-night-900/85">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between gap-3 px-4">
          <Link href="/" aria-label="Accueil NAFA"><Logo /></Link>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Navigation principale">
            {LINKS.map((l) => (
              <Link key={l.href} href={l.href} className={linkCls(l.href)}>
                <l.icon className="h-4 w-4" />
                {l.label}
              </Link>
            ))}
            {user?.role === "ADMIN" && (
              <Link href="/admin" className={linkCls("/admin")}>
                <ShieldCheck className="h-4 w-4" /> Admin
              </Link>
            )}
          </nav>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            {user ? (
              <>
                <Link href="/alerts" className="relative inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-card dark:border-white/10 dark:bg-white/10 dark:text-slate-300" aria-label={`Notifications (${unread} non lues)`}>
                  <Bell className="h-4.5 w-4.5" />
                  {unread > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                      {unread > 9 ? "9+" : unread}
                    </span>
                  )}
                </Link>
                <span className="hidden items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-600 dark:bg-white/10 dark:text-slate-200 sm:inline-flex">
                  <UserRound className="h-3.5 w-3.5" />
                  {user.name.split(" ")[0]}
                </span>
                <button
                  type="button"
                  onClick={logout}
                  disabled={pending}
                  aria-label="Déconnexion"
                  className="btn-3d inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-400 shadow-card transition hover:text-rose-500 dark:border-white/10 dark:bg-white/10"
                >
                  <LogOut className="h-4.5 w-4.5" />
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="btn-3d rounded-full bg-night-900 px-5 py-2.5 text-sm font-bold text-white shadow-card dark:bg-white dark:text-night-900"
              >
                Se connecter
              </Link>
            )}
          </div>
        </div>
        {error && <p className="pb-2 text-center text-xs font-bold text-rose-500">Déconnexion impossible — réessaie.</p>}
      </header>

      {/* Tab bar mobile */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200/80 bg-white/95 backdrop-blur-lg dark:border-white/10 dark:bg-night-900/95 md:hidden"
        aria-label="Navigation mobile"
      >
        <div className="grid grid-cols-4 gap-1 px-2 py-1.5">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={cn(
                "flex flex-col items-center gap-0.5 rounded-2xl py-2 text-[10px] font-bold transition",
                isActive(l.href)
                  ? "text-nafa-600 dark:text-nafa-300"
                  : "text-slate-400 dark:text-slate-500",
              )}
            >
              <l.icon className="h-5 w-5" />
              {l.label}
            </Link>
          ))}
        </div>
      </nav>
    </>
  );
}
