"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { Bell, BellOff, Loader2, Plus, Trash2 } from "lucide-react";
import { cn } from "@/lib/cn";
import { DirectionChip } from "./flags";

type Alert = {
  id: string;
  direction: "NGN_XOF" | "XOF_NGN";
  rateKind: "official" | "parallel";
  threshold: string;
  above: boolean;
  isActive: boolean;
  triggeredAt: string | Date | null;
};

export function AlertManager({ initial, ratesApplied }: {
  initial: Alert[];
  ratesApplied: { kind: "official" | "parallel"; applied: { NGN_XOF: number; XOF_NGN: number } }[];
}) {
  const router = useRouter();
  const [direction, setDirection] = useState<"NGN_XOF" | "XOF_NGN">("NGN_XOF");
  const [rateKind, setRateKind] = useState<"official" | "parallel">("parallel");
  const [above, setAbove] = useState(true);
  const [threshold, setThreshold] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const current = ratesApplied.find((r) => r.kind === rateKind)?.applied[direction];

  async function add(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          direction,
          rateKind,
          threshold: Number(threshold.replace(",", ".")),
          above,
        }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Impossible de créer l'alerte.");
        return;
      }
      setThreshold("");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  async function remove(id: string) {
    await fetch(`/api/alerts/${id}`, { method: "DELETE" });
    router.refresh();
  }

  const input =
    "w-full rounded-2xl border-2 border-slate-200 bg-slate-50/60 px-4 py-3 font-bold focus:border-nafa-400 focus:bg-white focus:outline-none dark:border-white/10 dark:bg-night-850";
  const select = input;

  const active = initial.filter((a) => a.isActive);
  const triggered = initial.filter((a) => !a.isActive && a.triggeredAt);

  return (
    <div className="space-y-6">
      {/* Création */}
      <form onSubmit={(e) => void add(e)} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-card dark:border-white/10 dark:bg-night-800">
        <h2 className="flex items-center gap-2 font-display text-lg font-bold">
          <Plus className="h-5 w-5 text-nafa-500" /> Nouvelle alerte de taux
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <select value={direction} onChange={(e) => setDirection(e.target.value as "NGN_XOF" | "XOF_NGN")} className={select} aria-label="Direction">
            <option value="NGN_XOF">₦ → F CFA</option>
            <option value="XOF_NGN">F CFA → ₦</option>
          </select>
          <select value={rateKind} onChange={(e) => setRateKind(e.target.value as "official" | "parallel")} className={select} aria-label="Type de taux">
            <option value="parallel">Marché parallèle</option>
            <option value="official">Taux officiel</option>
          </select>
          <select value={above ? "1" : "0"} onChange={(e) => setAbove(e.target.value === "1")} className={select} aria-label="Condition">
            <option value="1">Monte au-dessus (≥)</option>
            <option value="0">Descend en dessous (≤)</option>
          </select>
          <div className="relative">
            <input
              value={threshold}
              onChange={(e) => setThreshold(e.target.value)}
              inputMode="decimal"
              placeholder="Seuil, ex. 0.46"
              aria-label="Seuil de taux"
              className={input}
              required
            />
            {current !== undefined && (
              <span className="mt-1 block text-[11px] font-bold text-slate-400">
                Actuel : {direction === "NGN_XOF" ? current.toFixed(4) : current.toFixed(3)}
              </span>
            )}
          </div>
        </div>
        {error && <p role="alert" className="mt-3 rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-bold text-rose-600 dark:bg-rose-400/10">{error}</p>}
        <button type="submit" disabled={loading || !threshold}
          className="btn-3d mt-4 inline-flex items-center gap-2 rounded-2xl bg-night-900 px-6 py-3 font-display font-bold text-white shadow-card disabled:opacity-50 dark:bg-nafa-500 dark:text-night-950">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bell className="h-4 w-4" />}
          Créer l'alerte
        </button>
      </form>

      {/* Liste */}
      <section>
        <h2 className="mb-3 font-display text-lg font-bold">Alertes actives ({active.length}/10)</h2>
        {active.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-slate-300 p-8 text-center text-sm font-bold text-slate-400 dark:border-white/10">
            Aucune alerte — crée-en une pour être prévenu au bon moment.
          </p>
        ) : (
          <div className="grid gap-3">
            {active.map((a) => (
              <div key={a.id} className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-card dark:border-white/10 dark:bg-night-800">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-400/15 dark:text-amber-300">
                  <Bell className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display font-bold">
                    {a.above ? "≥" : "≤"} {a.direction === "NGN_XOF" ? Number(a.threshold).toFixed(4) : Number(a.threshold).toFixed(3)}
                    <span className="ml-2 font-sans text-xs font-bold text-slate-400">{a.rateKind === "official" ? "officiel" : "parallèle"}</span>
                  </p>
                  <p className="mt-0.5"><DirectionChip direction={a.direction} /></p>
                </div>
                <button type="button" onClick={() => void remove(a.id)} aria-label="Supprimer cette alerte"
                  className="btn-3d flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-400 hover:border-rose-200 hover:text-rose-500 dark:border-white/10">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {triggered.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Déclenchées</h2>
          <div className="grid gap-3">
            {triggered.map((a) => (
              <div key={a.id} className={cn("flex items-center gap-3 rounded-2xl border border-nafa-200 bg-nafa-50/60 p-4 dark:border-nafa-400/20 dark:bg-nafa-400/5")}>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-nafa-100 text-nafa-600 dark:bg-nafa-400/15">
                  <BellOff className="h-5 w-5" />
                </span>
                <p className="text-sm font-bold text-nafa-800 dark:text-nafa-200">
                  Seuil {a.above ? "≥" : "≤"} {a.threshold} atteint le {new Date(a.triggeredAt!).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
