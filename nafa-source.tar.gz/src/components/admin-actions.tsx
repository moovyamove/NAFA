"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { Check, CloudDownload, Loader2 } from "lucide-react";
import { cn } from "@/lib/cn";

/* ------------------------------ taux : édition ------------------------------ */

export function RateEditor({
  kind,
  initial,
}: {
  kind: "official" | "parallel";
  initial: { ngnToXof: number; xofToNgn: number; marginPercent: number };
}) {
  const router = useRouter();
  const [ngnToXof, setNgnToXof] = useState(String(initial.ngnToXof));
  const [xofToNgn, setXofToNgn] = useState(String(initial.xofToNgn));
  const [margin, setMargin] = useState(String(initial.marginPercent));
  const [state, setState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const input =
    "w-full rounded-xl border border-white/10 bg-night-850 px-3 py-2.5 font-display font-bold tabular-nums text-slate-100 focus:border-nafa-400 focus:outline-none";

  async function save(e: FormEvent) {
    e.preventDefault();
    setState("saving");
    setError(null);
    const res = await fetch("/api/admin/rates", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        kind,
        ngnToXof: Number(ngnToXof.replace(",", ".")),
        xofToNgn: Number(xofToNgn.replace(",", ".")),
        marginPercent: Number(margin.replace(",", ".")),
      }),
    });
    if (res.ok) {
      setState("saved");
      setTimeout(() => setState("idle"), 2200);
      router.refresh();
    } else {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Échec de la mise à jour.");
      setState("error");
    }
  }

  return (
    <form onSubmit={(e) => void save(e)} className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <label className="block">
          <span className="mb-1 block text-[10px] font-bold uppercase text-slate-500">1 ₦ → F CFA</span>
          <input value={ngnToXof} onChange={(e) => setNgnToXof(e.target.value)} inputMode="decimal" className={input} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[10px] font-bold uppercase text-slate-500">1 F CFA → ₦</span>
          <input value={xofToNgn} onChange={(e) => setXofToNgn(e.target.value)} inputMode="decimal" className={input} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[10px] font-bold uppercase text-slate-500">Marge %</span>
          <input value={margin} onChange={(e) => setMargin(e.target.value)} inputMode="decimal" className={input} />
        </label>
      </div>
      {error && <p role="alert" className="text-xs font-bold text-rose-400">{error}</p>}
      <button type="submit" disabled={state === "saving"}
        className="btn-3d inline-flex items-center gap-1.5 rounded-xl bg-nafa-500 px-4 py-2.5 text-sm font-bold text-night-950 disabled:opacity-50">
        {state === "saving" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
        {state === "saved" ? "Enregistré !" : "Appliquer"}
      </button>
    </form>
  );
}

/* ------------------------------ taux : refresh ------------------------------ */

export function RefreshRatesButton() {
  const router = useRouter();
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState<string | null>(null);

  async function refresh() {
    setState("loading");
    setMessage(null);
    try {
      const res = await fetch("/api/admin/rates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "refresh" }),
      });
      const data = (await res.json()) as { error?: string; ngnToXof?: number };
      if (!res.ok) {
        setState("error");
        setMessage(data.error ?? "API injoignable.");
        return;
      }
      setState("done");
      setMessage(`Cours officiel mis à jour : 1 ₦ = ${data.ngnToXof} F`);
      router.refresh();
    } finally {
      setTimeout(() => { setState("idle"); setMessage(null); }, 6000);
    }
  }

  return (
    <div>
      <button type="button" onClick={() => void refresh()} disabled={state === "loading"}
        className="btn-3d inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-bold text-slate-200 hover:bg-white/10 disabled:opacity-50">
        {state === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <CloudDownload className="h-4 w-4" />}
        Actualiser via API (open.er-api.com)
      </button>
      {message && (
        <p className={cn("animate-pop-in mt-2 text-xs font-bold", state === "error" ? "text-amber-400" : "text-nafa-300")}>{message}</p>
      )}
    </div>
  );
}

/* --------------------------- statuts de transaction --------------------------- */

const ACTIONS = [
  { to: "processing" as const, label: "En cours", cls: "bg-sky-500/15 text-sky-300" },
  { to: "success" as const, label: "Réussi", cls: "bg-nafa-500/15 text-nafa-300" },
  { to: "failed" as const, label: "Échec", cls: "bg-rose-500/15 text-rose-300" },
];

export function TxStatusButtons({ trackingId, current }: { trackingId: string; current: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);

  async function setStatus(status: string) {
    setBusy(status);
    await fetch("/api/admin/transactions", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trackingId, status }),
    });
    setBusy(null);
    router.refresh();
  }

  return (
    <span className="flex flex-wrap gap-1">
      {ACTIONS.map((a) => (
        <button
          key={a.to}
          type="button"
          disabled={busy !== null || current === a.to}
          onClick={() => void setStatus(a.to)}
          className={cn(
            "btn-3d rounded-full px-2.5 py-1 text-[11px] font-bold disabled:opacity-40",
            a.cls,
            current === a.to && "ring-1 ring-current",
          )}
        >
          {busy === a.to ? <Loader2 className="h-3 w-3 animate-spin" /> : a.label}
        </button>
      ))}
    </span>
  );
}
